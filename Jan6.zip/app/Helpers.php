<?php

use App\Models\Picture;
use App\Models\Post;
use App\Models\Setting;


function uploadImage($file, $folder)
{
    $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
    $file->move($folder, $filename);
    return $filename;
}

function getFooterData()
{
    $footerSetting = Setting::where('key', 'footer')->first();

    if (!$footerSetting) {
        return getDefaultFooterData();
    }

    $footerData = json_decode($footerSetting->value, true) ?? [];

    if ($footerSetting->status == 1) {
        // Merge with defaults to ensure all keys exist
        $defaults = getDefaultFooterData();
        $footer = array_merge($defaults, $footerData);
        $footer['status'] = true;
        return $footer;
    }

    return ['status' => false];
}

function getDefaultFooterData()
{
    return [
        'status' => true,
        'about' => [
            'title' => 'My World',
            'description' => 'A personal website to share my journey through photos, stories, and experiences. Built with Laravel and Bootstrap.',
            'social' => [
                'instagram' => '#',
                'twitter' => '#',
                'facebook' => '#',
                'pinterest' => '#',
                'youtube' => '#'
            ]
        ],
        'quick_links' => [
            ['label' => 'Home', 'url' => route('frontend.home')],
            ['label' => 'Gallery', 'url' => '#gallery'],
            ['label' => 'Posts', 'url' => route('frontend.posts')],
            ['label' => 'About', 'url' => route('frontend.about')],
            ['label' => 'Contact', 'url' => route('frontend.contact')]
        ],
        'social_platforms' => ['instagram', 'twitter', 'facebook', 'pinterest', 'youtube'],
        'contact' => [
            'email' => 'contact@myworld.com',
            'phone' => '+1 (555) 123-4567',
            'address' => '123 Personal Street, Memory City, MC 12345'
        ],
        'newsletter' => [
            'enabled' => true,
            'placeholder' => 'Your email',
            'button_text' => 'Subscribe'
        ],
        'style' => [
            'bg_color' => 'bg-dark',
            'text_color' => 'text-light',
            'icon_color' => 'text-light'
        ],
        'copyright' => '© ' . date('Y') . ' My World. All rights reserved.',
        'credit' => 'Built with <i class="fas fa-heart text-danger"></i> using Laravel & Bootstrap'
    ];
}




if (!function_exists('getAboutData')) {
    function getAboutData()
    {
        $aboutSetting = Setting::where('key', 'about')->first();
        
        if (!$aboutSetting) {
            return getDefaultAboutData();
        }
        
        $aboutData = json_decode($aboutSetting->value, true) ?? [];
        
        if ($aboutSetting->status == 1) {
            // Deep merge with defaults to ensure all keys exist
            $defaults = getDefaultAboutData();
            $data = array_merge_recursive_distinct($defaults, $aboutData);
    
            $data['status'] = true;
            return $data;
        }
        
        return ['status' => false];
    }
}

if (!function_exists('getDefaultAboutData')) {
    function getDefaultAboutData()
    {
        return [
            'status' => true,
            'images' => [
                'hero_bg' => '',
                'profile' => '',
            ],
            'hero' => [
                'text' => 'Welcome to my personal corner of the internet',
                'button_text' => 'My Story',
            ],
            'personalInfo' => [
                'name' => 'Alex',
                'location' => 'Somewhere Beautiful',
                'bio' => 'A curious soul wandering through life with a camera in hand and stories in heart.',
                'mission' => 'To capture the beauty in ordinary moments and share stories that connect us all.',
                'quote' => '"The world is full of stories waiting to be told, and I\'m here to listen."',
                'interests' => ['Photography', 'Writing', 'Hiking', 'Coffee Brewing', 'Reading', 'Stargazing'],
                'start_year' => 2018,
            ],
            'stats' => [
                'title' => 'My World in Numbers',
                'totalPosts' => Post::where('status','published')->count(),
                'totalPhotos' => Picture::where('type','gallery')->count(),
                'countriesFeatured' => 24,
                'yearsWriting' => date('Y') - 2018,
                'labels' => [
                    'stories' => 'Stories Shared',
                    'moments' => 'Moments Captured',
                    'countries' => 'Countries Featured',
                    'years' => 'Years of Journey',
                ],
            ],
            'values' => [
                'title' => 'What Guides My Journey',
                'items' => [
                    ['icon' => 'fas fa-heart', 'title' => 'Authenticity', 'description' => 'Keeping it real - no filters, no pretenses.'],
                    ['icon' => 'fas fa-compass', 'title' => 'Curiosity', 'description' => 'Always exploring, always learning, always wondering.'],
                    ['icon' => 'fas fa-hands', 'title' => 'Connection', 'description' => 'Building bridges through shared stories and experiences.'],
                    ['icon' => 'fas fa-sun', 'title' => 'Positivity', 'description' => 'Finding light even in challenging moments.'],
                ],
            ],
            'journey' => [
                'title' => 'My Journey So Far',
                'items' => [
                    ['year' => '2018', 'title' => 'The First Click', 'description' => 'Started documenting my daily life with a simple point-and-shoot camera.'],
                    ['year' => '2019', 'title' => 'Finding My Voice', 'description' => 'Began writing alongside photos, discovering the power of combined storytelling.'],
                    ['year' => '2020', 'title' => 'Going Digital', 'description' => 'Created My World blog to share my journey beyond social media.'],
                    ['year' => '2021', 'title' => 'First Solo Trip', 'description' => 'Traveled across the country, documenting every moment of self-discovery.'],
                    ['year' => '2022', 'title' => 'Finding Community', 'description' => 'Connected with fellow creators and started meaningful collaborations.'],
                    ['year' => '2023', 'title' => 'New Perspective', 'description' => 'Redesigned My World to focus on authentic, meaningful storytelling.'],
                ],
            ],
            'favorites' => [
                'title' => 'My Favorites',
                'items' => [
                    ['type' => 'Camera Gear', 'items' => ['Canon EOS R5', '24-70mm Lens', 'Tripod', 'Polarizing Filters']],
                    ['type' => 'Travel Essentials', 'items' => ['Journal', 'Coffee Kit', 'Comfortable Shoes', 'Portable Charger']],
                    ['type' => 'Creative Tools', 'items' => ['Moleskine Notebook', 'Fountain Pen', 'iPad Pro', 'Noise-canceling Headphones']],
                    ['type' => 'Reading List', 'items' => ['Into the Wild', 'The Alchemist', 'Wild', 'The Photographer\'s Eye']],
                ],
            ],
            'contact' => [
                'title' => 'Let\'s Connect',
                'description' => 'I love connecting with fellow travelers, photographers, and story lovers. Feel free to reach out!',
                'social' => [
                    'instagram' => '#',
                    'twitter' => '#',
                    'pinterest' => '#',
                    'email' => '#',
                ],
            ],
            'settings' => [
                'show_hero_images' => true,
                'show_personal_info' => true,
                'show_stats' => true,
                'show_values' => true,
                'show_journey' => true,
                'show_favorites' => true,
                'show_contact' => true,
            ]
        ];
    }
}

// Helper function for deep array merging
if (!function_exists('array_merge_recursive_distinct')) {
    function array_merge_recursive_distinct(array $array1, array $array2)
    {
        $merged = $array1;
        
        foreach ($array2 as $key => &$value) {
            if (is_array($value) && isset($merged[$key]) && is_array($merged[$key])) {
                if (is_assoc_array($value)) {
                    $merged[$key] = array_merge_recursive_distinct($merged[$key], $value);
                } else {
                    $merged[$key] = $value;
                }
            } else {
                $merged[$key] = $value;
            }
        }
        
        return $merged;
    }
}

if (!function_exists('is_assoc_array')) {
    function is_assoc_array(array $arr)
    {
        if (array() === $arr) return false;
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}



if (!function_exists('getContactData')) {
    function getContactData()
    {
        $contactSetting = Setting::where('key', 'contact')->first();
        
        if (!$contactSetting) {
            return getDefaultContactData();
        }
        
        $contactData = json_decode($contactSetting->value, true) ?? [];
        
        if ($contactSetting->status == 1) {
            // Deep merge with defaults to ensure all keys exist
            $defaults = getDefaultContactData();
            $data = array_merge_recursive_distinct($defaults, $contactData);
            $data['status'] = true;
            return $data;
        }
        
        return ['status' => false];
    }
}

if (!function_exists('getDefaultContactData')) {
    function getDefaultContactData()
    {
        return [
            'status' => true,
            'hero' => [
                'title' => 'Let\'s Connect',
                'description' => 'Have questions, ideas, or just want to say hello? I\'d love to hear from you.',
                'response_time' => 'I typically respond within 24-48 hours on weekdays.',
            ],
            'contactInfo' => [
                'email' => 'hello@myworld.com',
                'phone' => '+1 (555) 123-4567',
                'address' => '123 Creative Street, Inspiration City, IC 12345',
                'emergency_contact' => 'For urgent matters, please call during business hours.',
                'preferred_contact' => 'Email is the best way to reach me for non-urgent matters.',
                'social' => [
                    [
                        'platform' => 'instagram',
                        'icon' => 'fab fa-instagram',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'twitter',
                        'icon' => 'fab fa-twitter',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'pinterest',
                        'icon' => 'fab fa-pinterest',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'youtube',
                        'icon' => 'fab fa-youtube',
                        'url' => '#',
                        'handle' => 'My World',
                    ],
                ],
                'businessHours' => [
                    [
                        'day' => 'Monday - Friday',
                        'hours' => '9:00 AM - 6:00 PM',
                        'status' => 'open',
                    ],
                    [
                        'day' => 'Saturday',
                        'hours' => '10:00 AM - 4:00 PM',
                        'status' => 'limited',
                    ],
                    [
                        'day' => 'Sunday',
                        'hours' => 'Closed',
                        'status' => 'closed',
                    ],
                ],
                'faqs' => [
                    [
                        'question' => 'How long does it take to get a response?',
                        'answer' => 'I typically respond within 24-48 hours on weekdays. Weekend responses may take longer.',
                    ],
                    [
                        'question' => 'Do you accept guest posts?',
                        'answer' => 'Yes! I welcome guest posts that align with my blog\'s theme. Please email me your pitch with a brief outline of your proposed article.',
                    ],
                    [
                        'question' => 'Can I use your photos for personal projects?',
                        'answer' => 'Most photos are available for personal, non-commercial use with proper attribution. For commercial use, please contact me directly for licensing information.',
                    ],
                    [
                        'question' => 'Do you offer photography services?',
                        'answer' => 'Yes, I offer limited photography services for select projects. Email me with details about your project and I\'ll let you know if I can help.',
                    ],
                    [
                        'question' => 'Can I collaborate with you?',
                        'answer' => 'Absolutely! I\'m always open to creative collaborations. Send me your proposal and let\'s discuss how we can work together.',
                    ],
                    [
                        'question' => 'Do you have a newsletter?',
                        'answer' => 'Yes! You can subscribe to my newsletter on the homepage to get updates about new posts, photos, and behind-the-scenes content.',
                    ],
                ],
            ],
            'map' => [
                'title' => 'Find Me Here',
                'latitude' => '40.7128',
                'longitude' => '-74.0060',
                'zoom' => '13',
                'marker_title' => 'My World Headquarters',
                'marker_description' => 'Creative Street, Inspiration City',
            ],
            'form' => [
                'title' => 'Send Me a Message',
                'button_text' => 'Send Message',
                'button_icon' => 'fas fa-paper-plane',
                'success_message' => 'Your message has been sent successfully!',
                'enable_captcha' => false,
            ],
            'faq' => [
                'title' => 'Frequently Asked Questions',
            ],
            'settings' => [
                'show_hero' => true,
                'show_form' => true,
                'show_contact_info' => true,
                'show_social' => true,
                'show_business_hours' => true,
                'show_map' => true,
                'show_faq' => true,
                'enable_contact_form' => true,
            ],
        ];
    }
}