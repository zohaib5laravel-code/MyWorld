<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Comment;
use App\Models\ContactMessage;
use App\Models\Picture;
use App\Models\Post;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class FrontendController extends Controller
{
    public function index()
    {
        $pictures = Picture::get();

        $posts = Post::limit(3)
            ->where('status', 'published')
            ->orderBy('id', 'DESC')
            ->get();

        return view('frontend.index', compact('posts', 'pictures'));
    }


    public function posts(Request $request)
    {

        $query = Post::query()->where('status', 'published');

        // Search
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                    ->orWhere('content', 'like', "%{$search}%")
                    ->orWhere('excerpt', 'like', "%{$search}%");
            });
        }

        // Category filter
        if ($request->has('category') && $request->category) {
            $query->whereHas('category', function ($q) use ($request) {
                $q->where('id', $request->category);
            });
        }

        // Sort
        $sort = $request->get('sort', 'newest');
        switch ($sort) {
            case 'oldest':
                $query->orderBy('created_at', 'asc');
                break;
            case 'popular':
                $query->orderBy('views', 'desc');
                break;
            case 'commented':
                $query->withCount('approvedComments')
                    ->orderBy('approved_comments_count', 'desc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        $posts = $query->with(['category'])
            ->paginate(8)
            ->withQueryString();

        $categories = Category::where('status', 1)->get();
        $popularPosts = Post::where('status', 'published')
            ->orderBy('views', 'desc')
            ->limit(5)
            ->get();

        $postsPageSettings = Setting::where('key', 'posts')->first();
        $settings = $postsPageSettings ? json_decode($postsPageSettings->value, true) : [];

        return view('frontend.posts', compact('posts', 'categories', 'popularPosts', 'settings'));
    }

    public function post($slug)
    {
        $post = Post::where('slug', $slug)->first();
        $categories = Category::where('status', 1)->get();
        $relatedPosts = Post::where('category_id', $post->category_id)
            ->where('id', '!=', $post->id)
            ->where('status', 'published')
            ->inRandomOrder()
            ->limit(3)
            ->get();


        return view('frontend.post', compact('post', 'categories', 'relatedPosts'));
    }

    public function storeComment(Request $request, Post $post)
    {

        $comment = new Comment();
        $comment->post_id = $post->id;
        $comment->name = $request->input('name');
        //$comment->email = $request->input('email');
        $comment->comment = $request->input('comment');
        $comment->ip_address  = $request->ip();
        $comment->status = 0;
        $comment->save();


        return redirect()
            ->back()
            ->with('success', 'Your comment has been submitted and is awaiting moderation.');
    }

    public function gallery(Request $request)
    {
        $query = Picture::where('type', 'gallery');

        // Sort filter
        $sort = $request->get('sort', 'newest');
        switch ($sort) {
            case 'oldest':
                $query->orderBy('created_at', 'asc');
                break;
            case 'random':
                $query->inRandomOrder();
                break;
            case 'name':
                $query->orderBy('title', 'asc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        $pictures = $query->paginate(12)
            ->withQueryString();

        $categories = Category::where('status', 1)->get();
        $recentPictures = Picture::where('type', 'gallery')
            ->orderBy('created_at', 'desc')
            ->limit(8)
            ->get();

        return view('frontend.gallery', compact('pictures', 'categories', 'recentPictures'));
    }



    public function about()
    {
        // Get about page data using helper function
        $aboutData = getAboutData();

        // Extract data for view
        $personalInfo = $aboutData['personalInfo'] ?? [];
        $stats = $aboutData['stats'] ?? [];

        $journey = $aboutData['journey'] ?? [];
        $values = $aboutData['values'] ?? [];
        $favorites = $aboutData['favorites'] ?? [];
        $settings = $aboutData['settings'] ?? [];
        $status = $aboutData['status'] ?? [];

        return view('frontend.about', compact(
            'aboutData',
            'status',
            'personalInfo',
            'stats',
            'journey',
            'values',
            'favorites',
            'settings'
        ));
    }


    public function contact()
    {
        // Get contact data using helper function
        $contactData = getContactData();

        if (!$contactData['status']) {
            return view('frontend.maintenance', ['message' => 'Contact page is currently unavailable.']);
        }

        return view('frontend.contact', [
            'contactInfo' => $contactData['contactInfo'] ?? [],
            'hero' => $contactData['hero'] ?? [],
            'map' => $contactData['map'] ?? [],
            'form' => $contactData['form'] ?? [],
            'faq' => $contactData['faq'] ?? [],
            'settings' => $contactData['settings'] ?? [],
            'status' => $contactData['status'] ?? 0,
        ]);
    }

    public function sendMessage(Request $request)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'required|string|max:255',
            'message' => 'required|string|min:10|max:2000',
        ];

        $messages = [
            'name.required' => 'Please enter your name.',
            'email.required' => 'Please enter your email address.',
            'email.email' => 'Please enter a valid email address.',
            'subject.required' => 'Please enter a subject.',
            'message.required' => 'Please enter your message.',
            'message.min' => 'Your message should be at least 10 characters.',
            'message.max' => 'Your message should not exceed 2000 characters.',
        ];

        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect()
                ->route('frontend.contact')
                ->withErrors($validator)
                ->withInput()
                ->with('error', 'Please fix the errors below.');
        }

        try {
            if (class_exists(ContactMessage::class)) {
                ContactMessage::create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'subject' => $request->subject,
                    'message' => $request->message,
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->header('User-Agent'),
                    'status' => 'unread',
                ]);
            }

            ///$this->sendEmailNotification($request->all());
            Log::info('New contact form submission received:', [
                'name' => $request->name,
                'email' => $request->email,
                'subject' => $request->subject,
                'ip' => $request->ip(),
            ]);
            return redirect()
                ->route('frontend.contact')
                ->with('success', 'Thank you for your message! I\'ll get back to you within 24-48 hours.');
        } catch (\Exception $e) {
            Log::error('Contact form submission failed:', [
                'error' => $e->getMessage(),
                'data' => $request->except('message'),
            ]);
            return redirect()
                ->route('frontend.contact')
                ->with('error', 'Something went wrong. Please try again later.')
                ->withInput();
        }
    }
}
