<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SettingController extends Controller
{


    // Add this helper method to handle boolean fields
    private function handleBooleanFields($validated, $booleanFields)
    {
        // Ensure all boolean fields have values (0 or 1)
        foreach ($booleanFields as $field) {
            $keys = explode('.', $field);
            $lastKey = array_pop($keys);
            $array = &$validated;

            // Navigate through the array structure
            foreach ($keys as $key) {
                if (!isset($array[$key]) || !is_array($array[$key])) {
                    $array[$key] = [];
                }
                $array = &$array[$key];
            }

            // Set the boolean value - if not in request, set to 0
            if (!isset($array[$lastKey])) {
                $array[$lastKey] = 0;
            } else {
                // Ensure it's either 0 or 1
                $array[$lastKey] = $array[$lastKey] ? 1 : 0;
            }
        }

        return $validated;
    }

    // Footer methods (already updated)
    private function getDefaultFooter(): array
    {
        return [
            'about' => [
                'title' => '',
                'description' => '',
                'social' => [
                    'instagram' => '',
                    'twitter' => '',
                    'facebook' => '',
                    'pinterest' => '',
                    'youtube' => ''
                ]
            ],
            'quick_links' => [],
            'contact' => [
                'email' => '',
                'phone' => '',
                'address' => ''
            ],
            'newsletter' => [
                'enabled' => 0,
                'placeholder' => 'Enter your email',
                'button_text' => 'Subscribe'
            ],
            'style' => [
                'bg_class' => 'bg-dark',
                'text_class' => 'text-light',
                'link_class' => 'text-light text-decoration-none',
                'icon_class' => 'text-light'
            ],
            'copyright' => '© ' . date('Y') . ' My World. All rights reserved.',
            'credit' => 'Built with <i class="bi bi-heart text-danger"></i> using Laravel & Bootstrap'
        ];
    }

    private function getFooterValidationRules(): array
    {
        return [
            'status' => 'required|boolean',
            'footer.about.title' => 'nullable|string|max:255',
            'footer.about.description' => 'nullable|string|max:500',
            'footer.about.social.*' => 'nullable|url',
            'footer.quick_links.*.label' => 'required_with:footer.quick_links.*|string|max:50',
            'footer.quick_links.*.url' => 'nullable',
            'footer.contact.email' => 'nullable|email|max:255',
            'footer.contact.phone' => 'nullable|string|max:20',
            'footer.contact.address' => 'nullable|string|max:500',
            'footer.newsletter.enabled' => 'nullable|boolean',
            'footer.newsletter.placeholder' => 'nullable|string|max:100',
            'footer.newsletter.button_text' => 'nullable|string|max:50',
            'footer.style.bg_class' => 'nullable|string|max:100',
            'footer.style.text_class' => 'nullable|string|max:100',
            'footer.style.link_class' => 'nullable|string|max:100',
            'footer.style.icon_class' => 'nullable|string|max:100',
            'footer.copyright' => 'nullable|string|max:500',
            'footer.credit' => 'nullable|string|max:500'
        ];
    }

    public function editFooter()
    {
        $setting = Setting::firstOrCreate(
            ['key' => 'footer'],
            [
                'value' => json_encode($this->getDefaultFooter()),
                'status' => 1
            ]
        );

        $footer = json_decode($setting->value, true) ?? $this->getDefaultFooter();

        // Merge with defaults to ensure all keys exist
        $footer = array_merge($this->getDefaultFooter(), $footer);

        // Ensure nested arrays exist
        foreach (['about', 'contact', 'newsletter', 'style'] as $key) {
            $footer[$key] = array_merge($this->getDefaultFooter()[$key], $footer[$key] ?? []);
        }

        return view('admin.settings.footer', [
            'footer' => $footer,
            'status' => (bool) $setting->status,
            'social_platforms' => ['instagram', 'twitter', 'facebook', 'pinterest', 'youtube']
        ]);
    }

    public function updateFooter(Request $request)
    {
        $validator = Validator::make($request->all(), $this->getFooterValidationRules());

        if ($validator->fails()) {
            return redirect()
                ->back()
                ->withErrors($validator)
                ->withInput();
        }

        $data = $validator->validated();

        // Handle boolean fields
        $booleanFields = [
            'footer.newsletter.enabled'
        ];
        $data = $this->handleBooleanFields($data, $booleanFields);

        // Clean up quick links - remove empty entries
        if (isset($data['footer']['quick_links'])) {
            $data['footer']['quick_links'] = array_values(array_filter(
                $data['footer']['quick_links'],
                fn($link) => !empty($link['label']) || !empty($link['url'])
            ));
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultFooter();
        $finalData = array_replace_recursive($defaultData, $data['footer'] ?? []);

        // Store as JSON
        $setting = Setting::updateOrCreate(
            ['key' => 'footer'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $request->status
            ]
        );

        return redirect()
            ->back()
            ->with('success', 'Footer settings updated successfully.');
    }

    //About
    public function editAbout()
    {
        $setting = Setting::where('key', 'about')->first();

        $aboutData = $setting ? json_decode($setting->value, true) : [];

        // Merge with defaults to ensure all keys exist
        $aboutData = array_merge($this->getDefaultAboutData(), $aboutData);

        return view('admin.settings.about', [
            'aboutData' => $aboutData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function updateAbout(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',
            'hero_bg_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'hero.text' => 'nullable|string|max:500',
            'hero.button_text' => 'nullable|string|max:100',
            'personalInfo.name' => 'required|string|max:100',
            'personalInfo.location' => 'nullable|string|max:200',
            'personalInfo.bio' => 'required|string|max:1000',
            'personalInfo.mission' => 'nullable|string|max:1000',
            'personalInfo.quote' => 'nullable|string|max:500',
            'personalInfo.start_year' => 'nullable|integer|min:1900|max:' . date('Y'),
            'personalInfo.interests' => 'required|array|min:1',
            'personalInfo.interests.*' => 'required|string|max:100',

            'values.title' => 'nullable|string|max:200',
            'values.items' => 'nullable|array',
            'values.items.*.icon' => 'nullable|string|max:50',
            'values.items.*.title' => 'nullable|string|max:100',
            'values.items.*.description' => 'nullable|string|max:300',
            'journey.title' => 'nullable|string|max:200',
            'journey.items' => 'nullable|array',
            'journey.items.*.year' => 'nullable|string|max:10',
            'journey.items.*.title' => 'nullable|string|max:200',
            'journey.items.*.description' => 'nullable|string|max:500',
            'favorites.title' => 'nullable|string|max:200',
            'favorites.items' => 'nullable|array',
            'favorites.items.*.type' => 'nullable|string|max:100',
            'favorites.items.*.items' => 'nullable|string',
            'contact.title' => 'nullable|string|max:200',
            'contact.description' => 'nullable|string|max:500',
            'contact.social.instagram' => 'nullable|url|max:255',
            'contact.social.twitter' => 'nullable|url|max:255',
            'contact.social.pinterest' => 'nullable|url|max:255',
            'contact.social.email' => 'nullable|email|max:255',
            'settings.show_hero_images' => 'nullable|boolean',
            'settings.show_personal_info' => 'nullable|boolean',
            'settings.show_values' => 'nullable|boolean',
            'settings.show_journey' => 'nullable|boolean',
            'settings.show_favorites' => 'nullable|boolean',
            'settings.show_contact' => 'nullable|boolean',
            'remove_images.hero_bg' => 'nullable|boolean',
            'remove_images.profile' => 'nullable|boolean',
        ]);

        // Get existing data to preserve images
        $existingSetting = Setting::where('key', 'about')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultAboutData();

        // Initialize images array with existing images
        $images = $existingData['images'] ?? $this->getDefaultAboutData()['images'];

        // Handle image removal
        if ($request->has('remove_images.hero_bg') && $request->input('remove_images.hero_bg') == '1') {
            $images['hero_bg'] = '';
        }

        if ($request->has('remove_images.profile') && $request->input('remove_images.profile') == '1') {
            $images['profile'] = '';
        }

        // Handle image uploads
        if ($request->hasFile('hero_bg_image')) {
            $images['hero_bg'] = uploadImage($request->file('hero_bg_image'), 'assets/about');
        }

        if ($request->hasFile('profile_image')) {
            $images['profile'] = uploadImage($request->file('profile_image'), 'assets/about');
        }

        // Add images to validated data
        $validated['images'] = $images;

        // Handle boolean fields
        $booleanFields = [
            'settings.show_hero_images',
            'settings.show_personal_info',
            'settings.show_values',
            'settings.show_journey',
            'settings.show_favorites',
            'settings.show_contact'
        ];
        $validated = $this->handleBooleanFields($validated, $booleanFields);

        // Filter empty arrays
        if (isset($validated['values']['items'])) {
            $validated['values']['items'] = array_filter($validated['values']['items'], function ($item) {
                return !empty($item['title']) || !empty($item['description']);
            });
        }

        if (isset($validated['journey']['items'])) {
            $validated['journey']['items'] = array_filter($validated['journey']['items'], function ($item) {
                return !empty($item['title']) || !empty($item['description']);
            });
        }

        if (isset($validated['favorites']['items'])) {
            $validated['favorites']['items'] = array_filter($validated['favorites']['items'], function ($item) {
                return !empty($item['type']) && !empty($item['items']);
            });
        }

        // Convert favorites items from string to array
        if (isset($validated['favorites']['items'])) {
            foreach ($validated['favorites']['items'] as &$favorite) {
                if (is_string($favorite['items'])) {
                    $favorite['items'] = array_filter(array_map('trim', explode("\n", $favorite['items'])));
                }
            }
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultAboutData();
        $finalData = array_replace_recursive($defaultData, $validated);

        // Update or create setting
        Setting::updateOrCreate(
            ['key' => 'about'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'About page settings updated successfully.');
    }

    private function getDefaultAboutData()
    {
        return [
            'images' => [
                'hero_bg' => '',
                'profile' => '',
            ],
            'hero' => [
                'text' => 'Welcome to my personal corner of the internet',
                'button_text' => 'My Story',
            ],
            'personalInfo' => [
                'name' => 'Alex',
                'location' => 'Somewhere Beautiful',
                'bio' => 'A curious soul wandering through life with a camera in hand and stories in heart.',
                'mission' => 'To capture the beauty in ordinary moments and share stories that connect us all.',
                'quote' => '"The world is full of stories waiting to be told, and I\'m here to listen."',
                'interests' => ['Photography', 'Writing', 'Hiking', 'Coffee Brewing', 'Reading', 'Stargazing'],
                'start_year' => 2018,
            ],

            'values' => [
                'title' => 'What Guides My Journey',
                'items' => [
                    ['icon' => 'fas fa-heart', 'title' => 'Authenticity', 'description' => 'Keeping it real - no filters, no pretenses.'],
                    ['icon' => 'fas fa-compass', 'title' => 'Curiosity', 'description' => 'Always exploring, always learning, always wondering.'],
                    ['icon' => 'fas fa-hands', 'title' => 'Connection', 'description' => 'Building bridges through shared stories and experiences.'],
                    ['icon' => 'fas fa-sun', 'title' => 'Positivity', 'description' => 'Finding light even in challenging moments.'],
                ],
            ],
            'journey' => [
                'title' => 'My Journey So Far',
                'items' => [
                    ['year' => '2018', 'title' => 'The First Click', 'description' => 'Started documenting my daily life with a simple point-and-shoot camera.'],
                    ['year' => '2019', 'title' => 'Finding My Voice', 'description' => 'Began writing alongside photos, discovering the power of combined storytelling.'],
                    ['year' => '2020', 'title' => 'Going Digital', 'description' => 'Created My World blog to share my journey beyond social media.'],
                    ['year' => '2021', 'title' => 'First Solo Trip', 'description' => 'Traveled across the country, documenting every moment of self-discovery.'],
                    ['year' => '2022', 'title' => 'Finding Community', 'description' => 'Connected with fellow creators and started meaningful collaborations.'],
                    ['year' => '2023', 'title' => 'New Perspective', 'description' => 'Redesigned My World to focus on authentic, meaningful storytelling.'],
                ],
            ],
            'favorites' => [
                'title' => 'My Favorites',
                'items' => [
                    ['type' => 'Camera Gear', 'items' => ['Canon EOS R5', '24-70mm Lens', 'Tripod', 'Polarizing Filters']],
                    ['type' => 'Travel Essentials', 'items' => ['Journal', 'Coffee Kit', 'Comfortable Shoes', 'Portable Charger']],
                    ['type' => 'Creative Tools', 'items' => ['Moleskine Notebook', 'Fountain Pen', 'iPad Pro', 'Noise-canceling Headphones']],
                    ['type' => 'Reading List', 'items' => ['Into the Wild', 'The Alchemist', 'Wild', 'The Photographer\'s Eye']],
                ],
            ],
            'contact' => [
                'title' => 'Let\'s Connect',
                'description' => 'I love connecting with fellow travelers, photographers, and story lovers. Feel free to reach out!',
                'social' => [
                    'instagram' => '#',
                    'twitter' => '#',
                    'pinterest' => '#',
                    'email' => '#',
                ],
            ],
            'settings' => [
                'show_hero_images' => 1,
                'show_personal_info' => 1,
                'show_values' => 1,
                'show_journey' => 1,
                'show_favorites' => 1,
                'show_contact' => 1,
            ]
        ];
    }

    //Contact
    public function editContact()
    {
        $setting = Setting::where('key', 'contact')->first();

        $contactData = $setting ? json_decode($setting->value, true) : [];

        // Merge with defaults to ensure all keys exist
        $contactData = array_merge($this->getDefaultContactData(), $contactData);

        return view('admin.settings.contact', [
            'contactData' => $contactData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function updateContact(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',
            'hero.title' => 'required|string|max:200',
            'hero.description' => 'required|string|max:500',
            'hero.response_time' => 'nullable|string|max:200',
            'hero_bg_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'contactInfo.email' => 'required|email|max:255',
            'contactInfo.phone' => 'nullable|string|max:50',
            'contactInfo.address' => 'nullable|string|max:500',
            'contactInfo.emergency_contact' => 'nullable|string|max:200',
            'contactInfo.preferred_contact' => 'nullable|string|max:200',
            'contactInfo.social' => 'nullable|array',
            'contactInfo.social.*.platform' => 'required|string|max:50',
            'contactInfo.social.*.icon' => 'required|string|max:50',
            'contactInfo.social.*.url' => 'required|url|max:255',
            'contactInfo.social.*.handle' => 'nullable|string|max:100',
            'contactInfo.businessHours' => 'nullable|array',
            'contactInfo.businessHours.*.day' => 'required|string|max:100',
            'contactInfo.businessHours.*.hours' => 'required|string|max:100',
            'contactInfo.businessHours.*.status' => 'nullable|in:open,limited,closed',
            'contactInfo.faqs' => 'nullable|array',
            'contactInfo.faqs.*.question' => 'required|string|max:500',
            'contactInfo.faqs.*.answer' => 'required|string|max:1000',
            'map.title' => 'nullable|string|max:200',
            'map.latitude' => 'nullable|numeric',
            'map.longitude' => 'nullable|numeric',
            'map.zoom' => 'nullable|integer|min:1|max:18',
            'map.marker_title' => 'nullable|string|max:200',
            'map.marker_description' => 'nullable|string|max:500',
            'form.title' => 'nullable|string|max:200',
            'form.button_text' => 'nullable|string|max:50',
            'form.button_icon' => 'nullable|string|max:50',
            'form.success_message' => 'nullable|string|max:200',
            'form.enable_captcha' => 'nullable|boolean',
            'faq.title' => 'nullable|string|max:200',
            'settings.show_hero' => 'nullable|boolean',
            'settings.show_form' => 'nullable|boolean',
            'settings.show_contact_info' => 'nullable|boolean',
            'settings.show_social' => 'nullable|boolean',
            'settings.show_business_hours' => 'nullable|boolean',
            'settings.show_map' => 'nullable|boolean',
            'settings.show_faq' => 'nullable|boolean',
            'settings.enable_contact_form' => 'nullable|boolean',
            'remove_images.hero_bg' => 'nullable|boolean',
        ]);

        // Get existing data to preserve images
        $existingSetting = Setting::where('key', 'contact')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultContactData();

        $image = $existingData['hero']['hero_bg'] ?? '';

        // Handle image removal
        if ($request->has('remove_images.hero_bg') && $request->input('remove_images.hero_bg') == '1') {
            $image = '';
        }

        // Handle image uploads
        if ($request->hasFile('hero_bg_image')) {
            $image = uploadImage($request->file('hero_bg_image'), 'assets/contact');
        }

        // Add image to validated data
        $validated['hero']['hero_bg'] = $image;

        // Handle boolean fields
        $booleanFields = [
            'form.enable_captcha',
            'settings.show_hero',
            'settings.show_form',
            'settings.show_contact_info',
            'settings.show_social',
            'settings.show_business_hours',
            'settings.show_map',
            'settings.show_faq',
            'settings.enable_contact_form'
        ];
        $validated = $this->handleBooleanFields($validated, $booleanFields);

        if (isset($validated['contactInfo']['faqs'])) {
            $validated['contactInfo']['faqs'] = array_filter($validated['contactInfo']['faqs'], function ($item) {
                return !empty($item['question']) && !empty($item['answer']);
            });
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultContactData();
        $finalData = array_replace_recursive($defaultData, $validated);

        // Update or create setting
        Setting::updateOrCreate(
            ['key' => 'contact'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'Contact page settings updated successfully.');
    }

    private function getDefaultContactData()
    {
        return [
            'hero' => [
                'title' => 'Let\'s Connect',
                'description' => 'Have questions, ideas, or just want to say hello? I\'d love to hear from you.',
                'response_time' => 'I typically respond within 24-48 hours on weekdays.',
                'hero_bg' => '',
            ],
            'contactInfo' => [
                'email' => 'hello@myworld.com',
                'phone' => '+1 (555) 123-4567',
                'address' => '123 Creative Street, Inspiration City, IC 12345',
                'emergency_contact' => 'For urgent matters, please call during business hours.',
                'preferred_contact' => 'Email is the best way to reach me for non-urgent matters.',
                'social' => [
                    [
                        'platform' => 'instagram',
                        'icon' => 'fab fa-instagram',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'twitter',
                        'icon' => 'fab fa-twitter',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'pinterest',
                        'icon' => 'fab fa-pinterest',
                        'url' => '#',
                        'handle' => '@myworld',
                    ],
                    [
                        'platform' => 'youtube',
                        'icon' => 'fab fa-youtube',
                        'url' => '#',
                        'handle' => 'My World',
                    ],
                ],
                'businessHours' => [
                    [
                        'day' => 'Monday - Friday',
                        'hours' => '9:00 AM - 6:00 PM',
                        'status' => 'open',
                    ],
                    [
                        'day' => 'Saturday',
                        'hours' => '10:00 AM - 4:00 PM',
                        'status' => 'limited',
                    ],
                    [
                        'day' => 'Sunday',
                        'hours' => 'Closed',
                        'status' => 'closed',
                    ],
                ],
                'faqs' => [
                    [
                        'question' => 'How long does it take to get a response?',
                        'answer' => 'I typically respond within 24-48 hours on weekdays. Weekend responses may take longer.',
                    ],
                    [
                        'question' => 'Do you accept guest posts?',
                        'answer' => 'Yes! I welcome guest posts that align with my blog\'s theme. Please email me your pitch with a brief outline of your proposed article.',
                    ],
                    [
                        'question' => 'Can I use your photos for personal projects?',
                        'answer' => 'Most photos are available for personal, non-commercial use with proper attribution. For commercial use, please contact me directly for licensing information.',
                    ],
                    [
                        'question' => 'Do you offer photography services?',
                        'answer' => 'Yes, I offer limited photography services for select projects. Email me with details about your project and I\'ll let you know if I can help.',
                    ],
                    [
                        'question' => 'Can I collaborate with you?',
                        'answer' => 'Absolutely! I\'m always open to creative collaborations. Send me your proposal and let\'s discuss how we can work together.',
                    ],
                    [
                        'question' => 'Do you have a newsletter?',
                        'answer' => 'Yes! You can subscribe to my newsletter on the homepage to get updates about new posts, photos, and behind-the-scenes content.',
                    ],
                ],
            ],
            'map' => [
                'title' => 'Find Me Here',
                'latitude' => '40.7128',
                'longitude' => '-74.0060',
                'zoom' => '13',
                'marker_title' => 'My World Headquarters',
                'marker_description' => 'Creative Street, Inspiration City',
            ],
            'form' => [
                'title' => 'Send Me a Message',
                'button_text' => 'Send Message',
                'button_icon' => 'fas fa-paper-plane',
                'success_message' => 'Your message has been sent successfully!',
                'enable_captcha' => 0,
            ],
            'faq' => [
                'title' => 'Frequently Asked Questions',
            ],
            'settings' => [
                'show_hero' => 1,
                'show_form' => 1,
                'show_contact_info' => 1,
                'show_social' => 1,
                'show_business_hours' => 1,
                'show_map' => 1,
                'show_faq' => 1,
                'enable_contact_form' => 1,
            ],
        ];
    }



    public function editPosts()
    {
        $setting = Setting::where('key', 'posts')->first();

        $postsPageData = $setting ? json_decode($setting->value, true) : [];

        // Merge with defaults to ensure all keys exist
        $postsPageData = array_merge($this->getDefaultPostsPageData(), $postsPageData);

        return view('admin.settings.posts', [
            'postsPageData' => $postsPageData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function updatePosts(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',
            'hero.title' => 'nullable|string|max:200',
            'hero.description' => 'nullable|string|max:500',
            'hero.search_placeholder' => 'nullable|string|max:100',
            'filter.show_search' => 'nullable|boolean',
            'filter.show_category_filter' => 'nullable|boolean',
            'filter.show_sort_options' => 'nullable|boolean',
            'filter.default_sort' => 'nullable|in:newest,oldest,popular,commented',
            'filter.default_category' => 'nullable|exists:categories,id',
            'layout.posts_per_page' => 'nullable|integer|min:1|max:50',
            'layout.show_sidebar' => 'nullable|boolean',
            'layout.grid_columns' => 'nullable|in:2,3,4',
            'sidebar.show_about_widget' => 'nullable|boolean',
            'sidebar.show_categories_widget' => 'nullable|boolean',
            'sidebar.show_popular_posts_widget' => 'nullable|boolean',
            'sidebar.show_newsletter_widget' => 'nullable|boolean',
            'sidebar.about_widget_title' => 'nullable|string|max:200',
            'sidebar.about_widget_content' => 'nullable|string|max:1000',
            'sidebar.popular_posts_title' => 'nullable|string|max:200',
            'sidebar.popular_posts_count' => 'nullable|integer|min:1|max:10',
            'empty_state.title' => 'nullable|string|max:200',
            'empty_state.message' => 'nullable|string|max:500',
            'pagination.show_pagination' => 'nullable|boolean',
            'pagination.type' => 'nullable|in:simple,numbered,both',
            'meta.meta_title' => 'nullable|string|max:200',
            'meta.meta_description' => 'nullable|string|max:500',
            'meta.meta_keywords' => 'nullable|string|max:500',
            'hero_bg_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'remove_images.hero_bg' => 'nullable|boolean',
        ]);

        $existingSetting = Setting::where('key', 'posts')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultPostsPageData();

        $heroBgImage = $existingData['hero']['hero_bg'] ?? '';

        if ($request->has('remove_images.hero_bg') && $request->input('remove_images.hero_bg') == '1') {
            $heroBgImage = '';
        }

        if ($request->hasFile('hero_bg_image')) {
            $heroBgImage = uploadImage($request->file('hero_bg_image'), 'assets/posts-page');
        }

        $validated['hero']['hero_bg'] = $heroBgImage;
        $booleanFields = [
            'filter.show_search',
            'filter.show_category_filter',
            'filter.show_sort_options',
            'layout.show_sidebar',
            'sidebar.show_about_widget',
            'sidebar.show_categories_widget',
            'sidebar.show_popular_posts_widget',
            'sidebar.show_newsletter_widget',
            'pagination.show_pagination',
        ];

        // Set default values for boolean fields if not present in request
        foreach ($booleanFields as $field) {
            $keys = explode('.', $field);
            $lastKey = array_pop($keys);
            $array = &$validated;

            // Navigate through the array structure
            foreach ($keys as $key) {
                if (!isset($array[$key]) || !is_array($array[$key])) {
                    $array[$key] = [];
                }
                $array = &$array[$key];
            }

            // Set the boolean value - if not in request, set to 0
            if (!isset($array[$lastKey])) {
                $array[$lastKey] = 0;
            }
        }

        $defaultData = $this->getDefaultPostsPageData();
        $finalData = array_replace_recursive($defaultData, $validated);

        Setting::updateOrCreate(
            ['key' => 'posts'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'Posts page settings updated successfully.');
    }

    private function getDefaultPostsPageData()
    {
        return [
            'hero' => [
                'title' => 'My Stories & Thoughts',
                'description' => 'Explore my journey through personal stories, reflections, and experiences shared from my world.',
                'search_placeholder' => 'Search posts...',
                'hero_bg' => '',
            ],
            'filter' => [
                'show_search' => true,
                'show_category_filter' => true,
                'show_sort_options' => true,
                'default_sort' => 'newest',
                'default_category' => null,
            ],
            'layout' => [
                'posts_per_page' => 8,
                'show_sidebar' => true,
                'grid_columns' => 2, // 2 columns on medium screens
            ],
            'sidebar' => [
                'show_about_widget' => true,
                'show_categories_widget' => true,
                'show_popular_posts_widget' => true,
                'show_newsletter_widget' => true,
                'about_widget_title' => 'About This Blog',
                'about_widget_content' => 'Welcome to my personal blog where I share stories from my journey, thoughts on life, and experiences worth remembering. Every post is a piece of my world - from travels and adventures to quiet moments of reflection.',
                'popular_posts_title' => 'Popular Posts',
                'popular_posts_count' => 5,
            ],
            'empty_state' => [
                'title' => 'No Posts Found',
                'message' => 'Try adjusting your search or filter to find what you\'re looking for.',
            ],
            'pagination' => [
                'show_pagination' => true,
                'type' => 'both', // simple, numbered, both
            ],
            'meta' => [
                'meta_title' => 'My Stories & Thoughts | Blog',
                'meta_description' => 'Explore personal stories, reflections, and experiences from my journey.',
                'meta_keywords' => 'blog, stories, thoughts, personal, journey',
            ],
        ];
    }


    // Gallery     
    public function editGallery()
    {
        $setting = Setting::where('key', 'gallery')->first();

        $galleryData = $setting ? json_decode($setting->value, true) : [];

        // Merge with defaults to ensure all keys exist
        $galleryData = array_merge($this->getDefaultGalleryData(), $galleryData);

        return view('admin.settings.gallery', [
            'galleryData' => $galleryData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function updateGallery(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',
            'hero.title' => 'nullable|string|max:200',
            'hero.description' => 'nullable|string|max:500',
            'hero.show_stats' => 'nullable|boolean',
            'filter.show_sort_options' => 'nullable|boolean',
            'filter.default_sort' => 'nullable|in:newest,oldest,random,name',
            'layout.pictures_per_page' => 'nullable|integer|min:1|max:48',
            'layout.show_sidebar' => 'nullable|boolean',
            'layout.grid_columns' => 'nullable|in:2,3,4',
            'layout.masonry_enabled' => 'nullable|boolean',
            'sidebar.show_categories_widget' => 'nullable|boolean',
            'sidebar.show_recent_photos_widget' => 'nullable|boolean',
            'sidebar.show_tips_widget' => 'nullable|boolean',
            'sidebar.recent_photos_title' => 'nullable|string|max:200',
            'sidebar.recent_photos_count' => 'nullable|integer|min:1|max:12',
            'sidebar.tips_title' => 'nullable|string|max:200',
            'empty_state.title' => 'nullable|string|max:200',
            'empty_state.message' => 'nullable|string|max:500',
            'pagination.show_pagination' => 'nullable|boolean',
            'lightbox.enabled' => 'nullable|boolean',
            'lightbox.show_download_button' => 'nullable|boolean',
            'lightbox.show_fullscreen_button' => 'nullable|boolean',
            'lightbox.show_thumbnails' => 'nullable|boolean',
            'lightbox.keyboard_navigation' => 'nullable|boolean',
            'meta.meta_title' => 'nullable|string|max:200',
            'meta.meta_description' => 'nullable|string|max:500',
            'meta.meta_keywords' => 'nullable|string|max:500',
            'hero_bg_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'remove_images.hero_bg' => 'nullable|boolean',
        ]);

        // Get existing data to preserve images
        $existingSetting = Setting::where('key', 'gallery')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultGalleryData();

        // Handle image
        $heroBgImage = $existingData['hero']['hero_bg'] ?? '';

        if ($request->has('remove_images.hero_bg') && $request->input('remove_images.hero_bg') == '1') {
            $heroBgImage = '';
        }

        if ($request->hasFile('hero_bg_image')) {
            $heroBgImage = uploadImage($request->file('hero_bg_image'), 'assets/gallery');
        }

        // Add image to validated data
        $validated['hero']['hero_bg'] = $heroBgImage;

        // Initialize arrays if not exists
        if (!isset($validated['hero'])) {
            $validated['hero'] = [];
        }
        if (!isset($validated['filter'])) {
            $validated['filter'] = [];
        }
        if (!isset($validated['layout'])) {
            $validated['layout'] = [];
        }
        if (!isset($validated['sidebar'])) {
            $validated['sidebar'] = [];
        }
        if (!isset($validated['empty_state'])) {
            $validated['empty_state'] = [];
        }
        if (!isset($validated['pagination'])) {
            $validated['pagination'] = [];
        }
        if (!isset($validated['lightbox'])) {
            $validated['lightbox'] = [];
        }
        if (!isset($validated['meta'])) {
            $validated['meta'] = [];
        }

        // Handle boolean fields
        $booleanFields = [
            'hero.show_stats',
            'filter.show_sort_options',
            'layout.show_sidebar',
            'layout.masonry_enabled',
            'sidebar.show_categories_widget',
            'sidebar.show_recent_photos_widget',
            'sidebar.show_tips_widget',
            'pagination.show_pagination',
            'lightbox.enabled',
            'lightbox.show_download_button',
            'lightbox.show_fullscreen_button',
            'lightbox.show_thumbnails',
            'lightbox.keyboard_navigation',
        ];

        foreach ($booleanFields as $field) {
            $keys = explode('.', $field);
            $lastKey = array_pop($keys);
            $array = &$validated;

            // Navigate through the array structure
            foreach ($keys as $key) {
                if (!isset($array[$key]) || !is_array($array[$key])) {
                    $array[$key] = [];
                }
                $array = &$array[$key];
            }

            // Set the boolean value - if not in request, set to 0
            if (!isset($array[$lastKey])) {
                $array[$lastKey] = 0;
            } else {
                // Ensure it's 0 or 1
                $array[$lastKey] = $array[$lastKey] ? 1 : 0;
            }
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultGalleryData();
        $finalData = array_replace_recursive($defaultData, $validated);

        // Update or create setting
        Setting::updateOrCreate(
            ['key' => 'gallery'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'Gallery page settings updated successfully.');
    }

    private function getDefaultGalleryData()
    {
        return [
            'hero' => [
                'title' => 'My Visual Journey',
                'description' => 'Explore my world through photographs captured in moments of wonder, adventure, and quiet reflection.',
                'show_stats' => 1,
                'hero_bg' => '',
            ],
            'filter' => [
                'show_sort_options' => 1,
                'default_sort' => 'newest',
            ],
            'layout' => [
                'pictures_per_page' => 12,
                'show_sidebar' => 1,
                'grid_columns' => 3,
                'masonry_enabled' => 1,
            ],
            'sidebar' => [
                'show_categories_widget' => 1,
                'show_recent_photos_widget' => 1,
                'show_tips_widget' => 1,
                'recent_photos_title' => 'Recent Photos',
                'recent_photos_count' => 8,
                'tips_title' => 'Gallery Tips',
            ],
            'empty_state' => [
                'title' => 'No Photos Found',
                'message' => 'The gallery is empty. Photos will be added soon!',
            ],
            'pagination' => [
                'show_pagination' => 1,
            ],
            'lightbox' => [
                'enabled' => 1,
                'show_download_button' => 1,
                'show_fullscreen_button' => 1,
                'show_thumbnails' => 1,
                'keyboard_navigation' => 1,
            ],
            'meta' => [
                'meta_title' => 'My Visual Journey | Photo Gallery',
                'meta_description' => 'Explore my photography gallery featuring moments of wonder, adventure, and quiet reflection.',
                'meta_keywords' => 'gallery, photography, photos, images, visual journey',
            ],
        ];
    }


    // Homepage 

    public function editHomepage()
    {
        $setting = Setting::where('key', 'homepage')->first();

        $homepageData = $setting ? json_decode($setting->value, true) : [];

        // Merge with defaults to ensure all keys exist
        $homepageData = array_merge($this->getDefaultHomepageData(), $homepageData);

        return view('admin.settings.homepage', [
            'homepageData' => $homepageData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function updateHomepage(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',

            // Hero Section
            'hero.title' => 'nullable|string|max:200',
            'hero.subtitle' => 'nullable|string|max:500',
            'hero.button1_text' => 'nullable|string|max:50',
            'hero.button1_url' => 'nullable|string|max:255',
            'hero.button2_text' => 'nullable|string|max:50',
            'hero.button2_url' => 'nullable|string|max:255',
            'hero.show_world_icon' => 'nullable|boolean',

            // Banner Carousel
            'carousel.enabled' => 'nullable|boolean',
            'carousel.interval' => 'nullable|integer|min:1000|max:10000',
            'carousel.show_indicators' => 'nullable|boolean',
            'carousel.show_controls' => 'nullable|boolean',
            'carousel.show_captions' => 'nullable|boolean',
            'carousel.height' => 'nullable|integer|min:300|max:800',

            // Recent Posts Section
            'posts.enabled' => 'nullable|boolean',
            'posts.title' => 'nullable|string|max:200',
            'posts.subtitle' => 'nullable|string|max:500',
            'posts.show_button' => 'nullable|boolean',
            'posts.button_text' => 'nullable|string|max:50',
            'posts.posts_count' => 'nullable|integer|min:1|max:12',
            'posts.show_featured_image' => 'nullable|boolean',
            'posts.show_date' => 'nullable|boolean',
            'posts.show_category' => 'nullable|boolean',
            'posts.show_excerpt' => 'nullable|boolean',
            'posts.excerpt_length' => 'nullable|integer|min:50|max:500',

            // Gallery Section
            'gallery.enabled' => 'nullable|boolean',
            'gallery.title' => 'nullable|string|max:200',
            'gallery.subtitle' => 'nullable|string|max:500',
            'gallery.show_button' => 'nullable|boolean',
            'gallery.button_text' => 'nullable|string|max:50',
            'gallery.images_count' => 'nullable|integer|min:1|max:12',
            'gallery.show_overlay' => 'nullable|boolean',
            'gallery.columns' => 'nullable|in:2,3,4,6',

            // About Section
            'about.enabled' => 'nullable|boolean',
            'about.title' => 'nullable|string|max:200',
            'about.content' => 'nullable|string|max:2000',
            'about.show_image' => 'nullable|boolean',
            'about.image_url' => 'nullable|string|max:255',
            'about.show_social_icons' => 'nullable|boolean',
            'about.social_links' => 'nullable|array',
            'about.social_links.*.platform' => 'nullable|string|max:50',
            'about.social_links.*.url' => 'nullable|url|max:255',
            'about.social_links.*.icon' => 'nullable|string|max:50',

            // SEO Settings
            'meta.meta_title' => 'nullable|string|max:200',
            'meta.meta_description' => 'nullable|string|max:500',
            'meta.meta_keywords' => 'nullable|string|max:500',

            // Images
            'hero_bg_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'remove_images.hero_bg' => 'nullable|boolean',
        ]);

        // Get existing data to preserve images
        $existingSetting = Setting::where('key', 'homepage')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultHomepageData();

        // Handle hero background image
        $heroBgImage = $existingData['hero']['hero_bg'] ?? '';

        if ($request->has('remove_images.hero_bg') && $request->input('remove_images.hero_bg') == '1') {
            $heroBgImage = '';
        }

        if ($request->hasFile('hero_bg_image')) {
            $heroBgImage = uploadImage($request->file('hero_bg_image'), 'assets/homepage');
        }

        // Add image to validated data
        $validated['hero']['hero_bg'] = $heroBgImage;

        // Initialize arrays if not exists
        $sections = ['hero', 'carousel', 'posts', 'gallery', 'about', 'meta'];
        foreach ($sections as $section) {
            if (!isset($validated[$section])) {
                $validated[$section] = [];
            }
        }

        // Handle boolean fields
        $booleanFields = [
            'hero.show_world_icon',
            'carousel.enabled',
            'carousel.show_indicators',
            'carousel.show_controls',
            'carousel.show_captions',
            'posts.enabled',
            'posts.show_button',
            'posts.show_featured_image',
            'posts.show_date',
            'posts.show_category',
            'posts.show_excerpt',
            'gallery.enabled',
            'gallery.show_button',
            'gallery.show_overlay',
            'about.enabled',
            'about.show_image',
            'about.show_social_icons',
        ];

        foreach ($booleanFields as $field) {
            $keys = explode('.', $field);
            $lastKey = array_pop($keys);
            $array = &$validated;

            // Navigate through the array structure
            foreach ($keys as $key) {
                if (!isset($array[$key]) || !is_array($array[$key])) {
                    $array[$key] = [];
                }
                $array = &$array[$key];
            }

            // Set the boolean value - if not in request, set to 0
            if (!isset($array[$lastKey])) {
                $array[$lastKey] = 0;
            } else {
                // Ensure it's 0 or 1
                $array[$lastKey] = $array[$lastKey] ? 1 : 0;
            }
        }

        // Handle about social links
        if (isset($validated['about']['social_links'])) {
            $validated['about']['social_links'] = array_filter(
                $validated['about']['social_links'],
                function ($link) {
                    return !empty($link['platform']) && !empty($link['url']);
                }
            );
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultHomepageData();
        $finalData = array_replace_recursive($defaultData, $validated);

        // Update or create setting
        Setting::updateOrCreate(
            ['key' => 'homepage'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'Homepage settings updated successfully.');
    }

    private function getDefaultHomepageData()
    {
        return [
            'hero' => [
                'title' => 'Welcome to <span class="text-warning">My World</span>',
                'subtitle' => 'This is my personal space where I share my journey through photos, stories, and experiences. Every image tells a story, and every post captures a moment in time.',
                'button1_text' => 'Explore Gallery',
                'button1_url' => '#gallery',
                'button2_text' => 'Read Posts',
                'button2_url' => '#posts',
                'show_world_icon' => 1,
                'hero_bg' => '',
            ],
            'carousel' => [
                'enabled' => 1,
                'interval' => 5000,
                'show_indicators' => 1,
                'show_controls' => 1,
                'show_captions' => 1,
                'height' => 500,
            ],
            'posts' => [
                'enabled' => 1,
                'title' => 'Recent Posts',
                'subtitle' => '',
                'show_button' => 1,
                'button_text' => 'View All Posts',
                'posts_count' => 3,
                'show_featured_image' => 1,
                'show_date' => 1,
                'show_category' => 1,
                'show_excerpt' => 1,
                'excerpt_length' => 150,
            ],
            'gallery' => [
                'enabled' => 1,
                'title' => 'Photo Gallery',
                'subtitle' => 'A collection of my favorite moments captured through the lens',
                'show_button' => 1,
                'button_text' => 'View Full Gallery',
                'images_count' => 6,
                'show_overlay' => 1,
                'columns' => 3,
            ],
            'about' => [
                'enabled' => 1,
                'title' => 'About My World',
                'content' => 'Welcome to my personal corner of the internet. This space is a reflection of my journey, interests, and the moments that matter to me. Through photos and posts, I share glimpses of my experiences, thoughts, and discoveries. Each image in the gallery represents a memory, and every post is a story from my life.',
                'show_image' => 1,
                'image_url' => 'https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
                'show_social_icons' => 1,
                'social_links' => [
                    [
                        'platform' => 'instagram',
                        'url' => '#',
                        'icon' => 'fab fa-instagram',
                    ],
                    [
                        'platform' => 'twitter',
                        'url' => '#',
                        'icon' => 'fab fa-twitter',
                    ],
                    [
                        'platform' => 'facebook',
                        'url' => '#',
                        'icon' => 'fab fa-facebook',
                    ],
                    [
                        'platform' => 'pinterest',
                        'url' => '#',
                        'icon' => 'fab fa-pinterest',
                    ],
                ],
            ],
            'meta' => [
                'meta_title' => 'My World | Personal Blog & Gallery',
                'meta_description' => 'Welcome to My World - a personal space sharing journey through photos, stories, and experiences. Explore gallery, read posts, and discover my story.',
                'meta_keywords' => 'personal blog, photo gallery, travel, photography, stories, experiences',
            ],
        ];
    }



    // Menu Settings

    public function editMenu()
    {
        $setting = Setting::where('key', 'menu')->first();
        $menuData = $setting ? json_decode($setting->value, true) : [];
        $menuData = array_merge($this->getDefaultMenuData(), $menuData);

        return view('admin.settings.menu', [
            'menuData' => $menuData,
            'status' => $setting->status ?? 1
        ]);
    }

    public function editSections()
    {

        $menuSetting = Setting::where('key', 'menu')->first();
        $menuData = $menuSetting ? json_decode($menuSetting->value, true) : [];
        $menuData = array_merge($this->getDefaultMenuData(), $menuData);


        $footerSetting = Setting::where('key', 'footer')->first();
        $footer = json_decode($footerSetting->value, true) ?? $this->getDefaultFooter();
        $footer = array_merge($this->getDefaultFooter(), $footer);

        // Ensure nested arrays exist
        foreach (['about', 'contact', 'newsletter', 'style'] as $key) {
            $footer[$key] = array_merge($this->getDefaultFooter()[$key], $footer[$key] ?? []);
        };

        return view('admin.settings.sections', [
            'menu' => $menuData,
            'menu_status' => $menuSetting->status,
            'footer' => $footer,
            'footer_status' => $footerSetting->status,
            'social_platforms' => ['instagram', 'twitter', 'facebook', 'pinterest', 'youtube']

        ]);



        $tabs = ['footer', 'menu'];
        $data = [];

        foreach ($tabs as $tab) {
            $setting = Setting::where('key', $tab)->first();
            $method = 'getDefault' . ucfirst($tab) . 'Data';

            if ($setting) {
                $tabData = json_decode($setting->value, true) ?? [];
                $defaultData = method_exists($this, $method) ? $this->$method() : [];
                $data[$tab] = array_merge($defaultData, $tabData);
                $data[$tab . '_status'] = (bool) $setting->status;
            } else {
                $data[$tab] = method_exists($this, $method) ? $this->$method() : [];
                $data[$tab . '_status'] = true;
            }
        }

        return view('admin.settings.sections', $data);
    }

    public function updateMenu(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|boolean',

            // Logo/Brand Settings
            'logo.type' => 'nullable|in:text,image,both',
            'logo.text' => 'nullable|string|max:100',
            'logo.text_color' => 'nullable|string|max:50',
            'logo.text_size' => 'nullable|integer|min:12|max:48',

            // Navbar Settings
            'navbar.bg_color' => 'nullable|string|max:50',
            'navbar.text_color' => 'nullable|string|max:50',
            'navbar.hover_color' => 'nullable|string|max:50',
            'navbar.active_color' => 'nullable|string|max:50',
            'navbar.height' => 'nullable|integer|min:50|max:120',
            'navbar.position' => 'nullable|in:fixed-top,static,sticky-top',
            'navbar.transparent' => 'nullable|boolean',
            'navbar.show_home' => 'nullable|boolean',
            'navbar.show_gallery' => 'nullable|boolean',
            'navbar.show_posts' => 'nullable|boolean',
            'navbar.show_about' => 'nullable|boolean',
            'navbar.show_contact' => 'nullable|boolean',
            'navbar.show_search' => 'nullable|boolean',

            // Menu Items
            'items' => 'nullable|array',
            'items.*.label' => 'required|string|max:50',
            'items.*.url' => 'required|string|max:255',
            'items.*.route' => 'nullable|string|max:100',
            'items.*.icon' => 'nullable|string|max:50',
            'items.*.enabled' => 'nullable|boolean',
            'items.*.new_tab' => 'nullable|boolean',

            // Mobile Menu
            'mobile.enabled' => 'nullable|boolean',
            'mobile.collapse_breakpoint' => 'nullable|in:sm,md,lg,xl',
            'mobile.show_icons' => 'nullable|boolean',

            // Logo Image
            'logo_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'remove_images.logo' => 'nullable|boolean',
        ]);

        // Get existing data to preserve images
        $existingSetting = Setting::where('key', 'menu')->first();
        $existingData = $existingSetting ? json_decode($existingSetting->value, true) : $this->getDefaultMenuData();

        // Handle logo image
        $logoImage = $existingData['logo']['image'] ?? '';

        if ($request->has('remove_images.logo') && $request->input('remove_images.logo') == '1') {
            $logoImage = '';
        }

        if ($request->hasFile('logo_image')) {
            $logoImage = uploadImage($request->file('logo_image'), 'assets/menu');
        }

        // Add image to validated data
        $validated['logo']['image'] = $logoImage;

        // Initialize arrays if not exists
        if (!isset($validated['logo'])) {
            $validated['logo'] = [];
        }
        if (!isset($validated['navbar'])) {
            $validated['navbar'] = [];
        }
        if (!isset($validated['mobile'])) {
            $validated['mobile'] = [];
        }
        if (!isset($validated['items'])) {
            $validated['items'] = [];
        }

        // Handle boolean fields
        $booleanFields = [
            'navbar.transparent',
            'navbar.show_home',
            'navbar.show_gallery',
            'navbar.show_posts',
            'navbar.show_about',
            'navbar.show_contact',
            'navbar.show_search',
            'mobile.enabled',
            'mobile.show_icons',
        ];

        foreach ($booleanFields as $field) {
            $keys = explode('.', $field);
            $lastKey = array_pop($keys);
            $array = &$validated;

            // Navigate through the array structure
            foreach ($keys as $key) {
                if (!isset($array[$key]) || !is_array($array[$key])) {
                    $array[$key] = [];
                }
                $array = &$array[$key];
            }

            // Set the boolean value - if not in request, set to 0
            if (!isset($array[$lastKey])) {
                $array[$lastKey] = 0;
            } else {
                // Ensure it's 0 or 1
                $array[$lastKey] = $array[$lastKey] ? 1 : 0;
            }
        }

        // Handle menu items boolean fields
        if (isset($validated['items'])) {
            foreach ($validated['items'] as &$item) {
                if (!isset($item['enabled'])) {
                    $item['enabled'] = 0;
                } else {
                    $item['enabled'] = $item['enabled'] ? 1 : 0;
                }

                if (!isset($item['new_tab'])) {
                    $item['new_tab'] = 0;
                } else {
                    $item['new_tab'] = $item['new_tab'] ? 1 : 0;
                }
            }
        }

        // Ensure all defaults are set
        $defaultData = $this->getDefaultMenuData();
        $finalData = array_replace_recursive($defaultData, $validated);

        // Filter out disabled items
        if (isset($finalData['items'])) {
            $finalData['items'] = array_values(array_filter(
                $finalData['items'],
                function ($item) {
                    return $item['enabled'] == 1;
                }
            ));
        }

        // Update or create setting
        Setting::updateOrCreate(
            ['key' => 'menu'],
            [
                'value' => json_encode($finalData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                'status' => $finalData['status']
            ]
        );

        return redirect()->back()->with('success', 'Menu settings updated successfully.');
    }

    private function getDefaultMenuData()
    {
        return [
            'logo' => [
                'type' => 'text',
                'text' => 'My World',
                'text_color' => '#ffffff',
                'text_size' => 24,
                'image' => '',
            ],
            'navbar' => [
                'bg_color' => 'rgba(21, 26, 34, 0.95)',
                'text_color' => '#ffffff',
                'hover_color' => '#4a6fa5',
                'active_color' => '#166088',
                'height' => 70,
                'position' => 'fixed-top',
                'transparent' => 0,
                'show_home' => 1,
                'show_gallery' => 1,
                'show_posts' => 1,
                'show_about' => 1,
                'show_contact' => 1,
                'show_search' => 0,
            ],
            'items' => [
                [
                    'label' => 'Home',
                    'url' => '/',
                    'route' => 'frontend.home',
                    'icon' => 'fas fa-home',
                    'enabled' => 1,
                    'new_tab' => 0,
                ],
                [
                    'label' => 'Gallery',
                    'url' => '/gallery',
                    'route' => 'frontend.gallery',
                    'icon' => 'fas fa-images',
                    'enabled' => 1,
                    'new_tab' => 0,
                ],
                [
                    'label' => 'Posts',
                    'url' => '/posts',
                    'route' => 'frontend.posts',
                    'icon' => 'fas fa-newspaper',
                    'enabled' => 1,
                    'new_tab' => 0,
                ],
                [
                    'label' => 'About',
                    'url' => '/about',
                    'route' => 'frontend.about',
                    'icon' => 'fas fa-user-circle',
                    'enabled' => 1,
                    'new_tab' => 0,
                ],
                [
                    'label' => 'Contact',
                    'url' => '/contact',
                    'route' => 'frontend.contact',
                    'icon' => 'fas fa-envelope',
                    'enabled' => 1,
                    'new_tab' => 0,
                ],
            ],
            'mobile' => [
                'enabled' => 1,
                'collapse_breakpoint' => 'lg',
                'show_icons' => 1,
            ],
        ];
    }
}
