@extends('admin.app')

@section('content')
<main class="app-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-gradient-primary py-3">
                        <h4 class="mb-0">
                            <i class="fas fa-envelope me-2"></i>Contact Page Settings
                        </h4>
                        <small class="opacity-75">Customize your contact page content and layout</small>
                    </div>
                    
                    <form action="{{ route('settings.contact.update') }}" method="POST" id="contactForm" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            {{-- Page Status --}}
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">Contact Page Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                        <div class="form-text">When inactive, the contact page will show a maintenance message.</div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Hero Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-heading me-2"></i>Hero Section</h5>
                               
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                         <div class="col-md-6">
                                            <label class="form-label">Hero Background Image *</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="heroBgPreview">
                                                    @if(!empty($contactData['hero']['hero_bg']))
                                                        <img src="{{ asset('assets/contact/' . $contactData['hero']['hero_bg']) }}" 
                                                             class="img-fluid rounded" 
                                                             style="max-height: 150px;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[hero_bg]" 
                                                                       value="1"
                                                                       id="removeHeroBg">
                                                                <label class="form-check-label text-danger" for="removeHeroBg">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-mountain fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No background image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="hero_bg_image" 
                                                       class="form-control" 
                                                       id="heroBgInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[hero_bg]" 
                                                       value="{{ $contactData['hero']['hero_bg'] ?? '' }}">
                                                <div class="form-text">Recommended: 1920x1080px landscape image. URL: <code>{{ !empty($aboutData['images']['hero_bg']) ? asset('assets/about/' . $aboutData['images']['hero_bg']) : 'Not set' }}</code></div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Hero Title</label>
                                            <input type="text" 
                                                   name="hero[title]" 
                                                   class="form-control"
                                                   value="{{ old('hero.title', $contactData['hero']['title'] ?? 'Let\'s Connect') }}"
                                                   placeholder="e.g., Let's Connect"
                                                   required>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Description</label>
                                            <textarea name="hero[description]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="Have questions, ideas, or just want to say hello? I'd love to hear from you."
                                                      required>{{ old('hero.description', $contactData['hero']['description'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Response Time Note</label>
                                            <input type="text" 
                                                   name="hero[response_time]" 
                                                   class="form-control"
                                                   value="{{ old('hero.response_time', $contactData['hero']['response_time'] ?? 'I typically respond within 24-48 hours on weekdays.') }}"
                                                   placeholder="e.g., I typically respond within 24-48 hours on weekdays.">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Contact Information --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-address-card me-2"></i>Contact Information</h5>
                                 
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Email Address *</label>
                                            <input type="email" 
                                                   name="contactInfo[email]" 
                                                   class="form-control"
                                                   value="{{ old('contactInfo.email', $contactData['contactInfo']['email'] ?? 'hello@myworld.com') }}"
                                                   placeholder="hello@myworld.com"
                                                   required>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Phone Number</label>
                                            <input type="text" 
                                                   name="contactInfo[phone]" 
                                                   class="form-control"
                                                   value="{{ old('contactInfo.phone', $contactData['contactInfo']['phone'] ?? '+1 (555) 123-4567') }}"
                                                   placeholder="+1 (555) 123-4567">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Address</label>
                                            <textarea name="contactInfo[address]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="123 Creative Street, Inspiration City, IC 12345">{{ old('contactInfo.address', $contactData['contactInfo']['address'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Emergency Contact Note</label>
                                            <input type="text" 
                                                   name="contactInfo[emergency_contact]" 
                                                   class="form-control"
                                                   value="{{ old('contactInfo.emergency_contact', $contactData['contactInfo']['emergency_contact'] ?? 'For urgent matters, please call during business hours.') }}"
                                                   placeholder="For urgent matters, please call during business hours.">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Preferred Contact Note</label>
                                            <input type="text" 
                                                   name="contactInfo[preferred_contact]" 
                                                   class="form-control"
                                                   value="{{ old('contactInfo.preferred_contact', $contactData['contactInfo']['preferred_contact'] ?? 'Email is the best way to reach me for non-urgent matters.') }}"
                                                   placeholder="Email is the best way to reach me for non-urgent matters.">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                           
                             
                            
                            {{-- FAQ Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-question-circle me-2"></i>FAQ Section</h5>
                                  
                                </div>
                                <div class="card-body">
                                    <div class="row g-3 mb-3">
                                        <div class="col-12">
                                            <label class="form-label">FAQ Section Title</label>
                                            <input type="text" 
                                                   name="faq[title]" 
                                                   class="form-control"
                                                   value="{{ old('faq.title', $contactData['faq']['title'] ?? 'Frequently Asked Questions') }}"
                                                   placeholder="e.g., Frequently Asked Questions">
                                        </div>
                                    </div>
                                    
                                    <div id="faqContainer">
                                        @php
                                            $faqs = old('contactInfo.faqs', $contactData['contactInfo']['faqs'] ?? [
                                                [
                                                    'question' => 'How long does it take to get a response?',
                                                    'answer' => 'I typically respond within 24-48 hours on weekdays. Weekend responses may take longer.'
                                                ],
                                                [
                                                    'question' => 'Do you accept guest posts?',
                                                    'answer' => 'Yes! I welcome guest posts that align with my blog\'s theme. Please email me your pitch with a brief outline of your proposed article.'
                                                ],
                                                [
                                                    'question' => 'Can I use your photos for personal projects?',
                                                    'answer' => 'Most photos are available for personal, non-commercial use with proper attribution. For commercial use, please contact me directly for licensing information.'
                                                ],
                                                [
                                                    'question' => 'Do you offer photography services?',
                                                    'answer' => 'Yes, I offer limited photography services for select projects. Email me with details about your project and I\'ll let you know if I can help.'
                                                ],
                                                [
                                                    'question' => 'Can I collaborate with you?',
                                                    'answer' => 'Absolutely! I\'m always open to creative collaborations. Send me your proposal and let\'s discuss how we can work together.'
                                                ],
                                                [
                                                    'question' => 'Do you have a newsletter?',
                                                    'answer' => 'Yes! You can subscribe to my newsletter on the homepage to get updates about new posts, photos, and behind-the-scenes content.'
                                                ],
                                            ]);
                                        @endphp
                                        @foreach($faqs as $index => $faq)
                                            <div class="faq-item card mb-3" data-index="{{ $index }}">
                                                <div class="card-body">
                                                    <div class="row g-3">
                                                        <div class="col-md-5">
                                                            <label class="form-label small">Question *</label>
                                                            <input type="text" 
                                                                   name="contactInfo[faqs][{{ $index }}][question]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $faq['question'] ?? '' }}"
                                                                   placeholder="How long does it take to get a response?"
                                                                   required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label small">Answer *</label>
                                                            <textarea name="contactInfo[faqs][{{ $index }}][answer]"
                                                                      class="form-control form-control-sm"
                                                                      rows="2"
                                                                      placeholder="I typically respond within 24-48 hours on weekdays."
                                                                      required>{{ $faq['answer'] ?? '' }}</textarea>
                                                        </div>
                                                        <div class="col-md-1 d-flex align-items-end">
                                                            <button type="button" class="btn btn-sm btn-outline-danger remove-faq">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button type="button" id="addFaq" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-plus me-1"></i> Add FAQ
                                    </button>
                                </div>
                            </div>
                            
                            {{-- Map Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-map-marked-alt me-2"></i>Map Section</h5>
                                 
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label">Map Section Title</label>
                                            <input type="text" 
                                                   name="map[title]" 
                                                   class="form-control"
                                                   value="{{ old('map.title', $contactData['map']['title'] ?? 'Find Me Here') }}"
                                                   placeholder="e.g., Find Me Here">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Latitude</label>
                                            <input type="number" 
                                                   step="any"
                                                   name="map[latitude]" 
                                                   class="form-control"
                                                   value="{{ old('map.latitude', $contactData['map']['latitude'] ?? '40.7128') }}"
                                                   placeholder="40.7128">
                                            <div class="form-text small">Map center latitude coordinate</div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Longitude</label>
                                            <input type="number" 
                                                   step="any"
                                                   name="map[longitude]" 
                                                   class="form-control"
                                                   value="{{ old('map.longitude', $contactData['map']['longitude'] ?? '-74.0060') }}"
                                                   placeholder="-74.0060">
                                            <div class="form-text small">Map center longitude coordinate</div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Zoom Level</label>
                                            <input type="number" 
                                                   min="1"
                                                   max="18"
                                                   name="map[zoom]" 
                                                   class="form-control"
                                                   value="{{ old('map.zoom', $contactData['map']['zoom'] ?? '13') }}"
                                                   placeholder="13">
                                            <div class="form-text small">1 (world) to 18 (street)</div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Marker Title</label>
                                            <input type="text" 
                                                   name="map[marker_title]" 
                                                   class="form-control"
                                                   value="{{ old('map.marker_title', $contactData['map']['marker_title'] ?? 'My World Headquarters') }}"
                                                   placeholder="My World Headquarters">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Marker Description</label>
                                            <textarea name="map[marker_description]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="Creative Street, Inspiration City">{{ old('map.marker_description', $contactData['map']['marker_description'] ?? '') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Form Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-paper-plane me-2"></i>Contact Form</h5>
                                
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label">Form Title</label>
                                            <input type="text" 
                                                   name="form[title]" 
                                                   class="form-control"
                                                   value="{{ old('form.title', $contactData['form']['title'] ?? 'Send Me a Message') }}"
                                                   placeholder="e.g., Send Me a Message">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Button Text</label>
                                            <input type="text" 
                                                   name="form[button_text]" 
                                                   class="form-control"
                                                   value="{{ old('form.button_text', $contactData['form']['button_text'] ?? 'Send Message') }}"
                                                   placeholder="e.g., Send Message">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Button Icon</label>
                                            <input type="text" 
                                                   name="form[button_icon]" 
                                                   class="form-control"
                                                   value="{{ old('form.button_icon', $contactData['form']['button_icon'] ?? 'fas fa-paper-plane') }}"
                                                   placeholder="fas fa-paper-plane">
                                            <div class="form-text small">Font Awesome class</div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Success Message</label>
                                            <input type="text" 
                                                   name="form[success_message]" 
                                                   class="form-control"
                                                   value="{{ old('form.success_message', $contactData['form']['success_message'] ?? 'Your message has been sent successfully!') }}"
                                                   placeholder="Your message has been sent successfully!">
                                        </div>
                                        
                                        <div class="col-12">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="form[enable_captcha]"
                                                       value="1"
                                                       {{ old('form.enable_captcha', $contactData['form']['enable_captcha'] ?? false) ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable reCAPTCHA</label>
                                                <div class="form-text small">Requires reCAPTCHA API keys</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Section Visibility Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-eye me-2"></i>Section Visibility</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_hero]"
                                                       value="1"
                                                       {{ old('settings.show_hero', $contactData['settings']['show_hero'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Hero Section</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_form]"
                                                       value="1"
                                                       {{ old('settings.show_form', $contactData['settings']['show_form'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Contact Form</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_contact_info]"
                                                       value="1"
                                                       {{ old('settings.show_contact_info', $contactData['settings']['show_contact_info'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Contact Info</label>
                                            </div>
                                         
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_business_hours]"
                                                       value="1"
                                                       {{ old('settings.show_business_hours', $contactData['settings']['show_business_hours'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Business Hours</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_map]"
                                                       value="1"
                                                       {{ old('settings.show_map', $contactData['settings']['show_map'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Map</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_faq]"
                                                       value="1"
                                                       {{ old('settings.show_faq', $contactData['settings']['show_faq'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show FAQ Section</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[enable_contact_form]"
                                                       value="1"
                                                       {{ old('settings.enable_contact_form', $contactData['settings']['enable_contact_form'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Contact Form Submission</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Reset Changes
                                </button>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-1"></i> Save Contact Page Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection



@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {

     function setupImagePreview(inputId, previewId, isCircle = false) {
        const input = document.getElementById(inputId);
        const preview = document.getElementById(previewId);
        
        if (input && preview) {
            input.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = isCircle ? 'img-fluid rounded-circle' : 'img-fluid rounded';
                        img.style = isCircle ? 'width: 150px; height: 150px; object-fit: cover;' : 'max-height: 150px;';
                        
                        preview.innerHTML = '';
                        
                        // Create image container
                        const imgContainer = document.createElement('div');
                        imgContainer.appendChild(img);
                        
                        // Add remove checkbox
                        const removeDiv = document.createElement('div');
                        removeDiv.className = 'mt-2';
                        removeDiv.innerHTML = `
                            <div class="form-check">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="remove_images[${inputId.replace('Input', '')}]" 
                                       value="1"
                                       id="remove${inputId}">
                                <label class="form-check-label text-danger" for="remove${inputId}">
                                    Remove this image
                                </label>
                            </div>
                        `;
                        
                        preview.appendChild(imgContainer);
                        preview.appendChild(removeDiv);
                    };
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
        }
    }
    
    // Set up image previews
    setupImagePreview('heroBgInput', 'heroBgPreview', false);
    // Section toggling
    document.querySelectorAll('.section-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const cardBody = this.closest('.section-card').querySelector('.card-body');
            if (this.checked) {
                cardBody.style.opacity = '1';
                cardBody.style.pointerEvents = 'auto';
            } else {
                cardBody.style.opacity = '0.6';
                cardBody.style.pointerEvents = 'none';
            }
        });
        
        // Initialize toggle state
        toggle.dispatchEvent(new Event('change'));
    });
 
    
    // Business Hours Management
    let hoursIndex = {{ count($contactData['contactInfo']['businessHours'] ?? []) }};
    document.getElementById('addBusinessHours').addEventListener('click', function() {
        const container = document.getElementById('businessHoursContainer');
        const html = `
            <div class="hours-item card mb-3" data-index="${hoursIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label small">Day/Period *</label>
                            <input type="text" 
                                   name="contactInfo[businessHours][${hoursIndex}][day]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., Monday - Friday"
                                   required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small">Hours *</label>
                            <input type="text" 
                                   name="contactInfo[businessHours][${hoursIndex}][hours]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., 9:00 AM - 6:00 PM"
                                   required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small">Status</label>
                            <select name="contactInfo[businessHours][${hoursIndex}][status]"
                                    class="form-select form-select-sm">
                                <option value="open">Open</option>
                                <option value="limited">Limited Hours</option>
                                <option value="closed">Closed</option>
                            </select>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-hours">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        hoursIndex++;
    });
    
    document.getElementById('businessHoursContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-hours')) {
            e.target.closest('.hours-item').remove();
            reindexItems('businessHoursContainer', 'businessHours');
        }
    });
    
    // FAQ Management
    let faqIndex = {{ count($contactData['contactInfo']['faqs'] ?? []) }};
    document.getElementById('addFaq').addEventListener('click', function() {
        const container = document.getElementById('faqContainer');
        const html = `
            <div class="faq-item card mb-3" data-index="${faqIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <label class="form-label small">Question *</label>
                            <input type="text" 
                                   name="contactInfo[faqs][${faqIndex}][question]"
                                   class="form-control form-control-sm"
                                   placeholder="How long does it take to get a response?"
                                   required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Answer *</label>
                            <textarea name="contactInfo[faqs][${faqIndex}][answer]"
                                      class="form-control form-control-sm"
                                      rows="2"
                                      placeholder="I typically respond within 24-48 hours on weekdays."
                                      required></textarea>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-faq">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        faqIndex++;
    });
    
    document.getElementById('faqContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-faq')) {
            e.target.closest('.faq-item').remove();
            reindexItems('faqContainer', 'faqs');
        }
    });
    
    function reindexItems(containerId, prefix) {
        const container = document.getElementById(containerId);
        const items = container.querySelectorAll(`.${prefix}-item`);
        items.forEach((item, index) => {
            item.dataset.index = index;
            const inputs = item.querySelectorAll('input, textarea, select');
            inputs.forEach(input => {
                const name = input.name.replace(
                    new RegExp(`${prefix}\\[\\d+\\]`), 
                    `${prefix}[${index}]`
                );
                input.name = name;
            });
        });
        window[prefix + 'Index'] = items.length;
    }
});
</script>
@endsection