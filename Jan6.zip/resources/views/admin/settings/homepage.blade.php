{{-- resources/views/admin/settings/homepage.blade.php --}}
@extends('admin.app')

@section('content')
<main class="app-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-gradient-primary py-3">
                        <h4 class="mb-0">
                            <i class="fas fa-home me-2"></i>Homepage Settings
                        </h4>
                        <small class="opacity-75">Customize your homepage layout and content</small>
                    </div>
                    
                    <form action="{{ route('settings.homepage.update') }}" method="POST" id="homepageForm" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            {{-- Page Status --}}
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">Homepage Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                        <div class="form-text">When inactive, visitors will be redirected or shown maintenance page.</div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Hero Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-star me-2"></i>Hero Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Background Image</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="heroBgPreview">
                                                    @if(!empty($homepageData['hero']['hero_bg']))
                                                        <img src="{{ asset('assets/homepage/' . $homepageData['hero']['hero_bg']) }}" 
                                                             class="img-fluid rounded" 
                                                             style="max-height: 150px;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[hero_bg]" 
                                                                       value="1"
                                                                       id="removeHeroBg">
                                                                <label class="form-check-label text-danger" for="removeHeroBg">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-image fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No background image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="hero_bg_image" 
                                                       class="form-control" 
                                                       id="heroBgInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[hero_bg]" 
                                                       value="{{ $homepageData['hero']['hero_bg'] ?? '' }}">
                                                <div class="form-text">Background image for hero section</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="hero[show_world_icon]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="hero[show_world_icon]"
                                                       value="1"
                                                       {{ isset($homepageData['hero']['show_world_icon']) && $homepageData['hero']['show_world_icon'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show World Icon</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Title</label>
                                            <input type="text" 
                                                   name="hero[title]" 
                                                   class="form-control"
                                                   value="{{ old('hero.title', $homepageData['hero']['title'] ?? '') }}"
                                                   placeholder="Welcome to My World">
                                            <div class="form-text">You can use HTML tags like &lt;span class=&quot;text-warning&quot;&gt; for styling</div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Subtitle</label>
                                            <textarea name="hero[subtitle]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="This is my personal space where I share my journey...">{{ old('hero.subtitle', $homepageData['hero']['subtitle'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Primary Button Text</label>
                                            <input type="text" 
                                                   name="hero[button1_text]" 
                                                   class="form-control"
                                                   value="{{ old('hero.button1_text', $homepageData['hero']['button1_text'] ?? 'Explore Gallery') }}">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Primary Button URL</label>
                                            <input type="text" 
                                                   name="hero[button1_url]" 
                                                   class="form-control"
                                                   value="{{ old('hero.button1_url', $homepageData['hero']['button1_url'] ?? '#gallery') }}">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Secondary Button Text</label>
                                            <input type="text" 
                                                   name="hero[button2_text]" 
                                                   class="form-control"
                                                   value="{{ old('hero.button2_text', $homepageData['hero']['button2_text'] ?? 'Read Posts') }}">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Secondary Button URL</label>
                                            <input type="text" 
                                                   name="hero[button2_url]" 
                                                   class="form-control"
                                                   value="{{ old('hero.button2_url', $homepageData['hero']['button2_url'] ?? '#posts') }}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Banner Carousel Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-images me-2"></i>Banner Carousel</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="carousel[enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="carousel[enabled]"
                                                       value="1"
                                                       {{ isset($homepageData['carousel']['enabled']) && $homepageData['carousel']['enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Carousel</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="carousel[show_indicators]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="carousel[show_indicators]"
                                                       value="1"
                                                       {{ isset($homepageData['carousel']['show_indicators']) && $homepageData['carousel']['show_indicators'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Indicators</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="carousel[show_controls]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="carousel[show_controls]"
                                                       value="1"
                                                       {{ isset($homepageData['carousel']['show_controls']) && $homepageData['carousel']['show_controls'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Navigation Controls</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="carousel[show_captions]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="carousel[show_captions]"
                                                       value="1"
                                                       {{ isset($homepageData['carousel']['show_captions']) && $homepageData['carousel']['show_captions'] == 1 ? 'checked' : '' }}>
                                                <label class="form-label">Show Image Captions</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Carousel Interval (ms)</label>
                                                <input type="number" 
                                                       name="carousel[interval]" 
                                                       class="form-control"
                                                       value="{{ old('carousel.interval', $homepageData['carousel']['interval'] ?? 5000) }}"
                                                       min="1000"
                                                       max="10000">
                                                <div class="form-text">Time between slides in milliseconds (1000-10000)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Carousel Height (px)</label>
                                                <input type="number" 
                                                       name="carousel[height]" 
                                                       class="form-control"
                                                       value="{{ old('carousel.height', $homepageData['carousel']['height'] ?? 500) }}"
                                                       min="300"
                                                       max="800">
                                                <div class="form-text">Height of carousel images in pixels (300-800)</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Recent Posts Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-newspaper me-2"></i>Recent Posts Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[enabled]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['enabled']) && $homepageData['posts']['enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Posts Section</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[show_button]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[show_button]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['show_button']) && $homepageData['posts']['show_button'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show "View All" Button</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[show_featured_image]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[show_featured_image]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['show_featured_image']) && $homepageData['posts']['show_featured_image'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Featured Images</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[show_date]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[show_date]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['show_date']) && $homepageData['posts']['show_date'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Post Date</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[show_category]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[show_category]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['show_category']) && $homepageData['posts']['show_category'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Category</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="posts[show_excerpt]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="posts[show_excerpt]"
                                                       value="1"
                                                       {{ isset($homepageData['posts']['show_excerpt']) && $homepageData['posts']['show_excerpt'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Excerpt</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Section Title</label>
                                                <input type="text" 
                                                       name="posts[title]" 
                                                       class="form-control"
                                                       value="{{ old('posts.title', $homepageData['posts']['title'] ?? 'Recent Posts') }}">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Section Subtitle (Optional)</label>
                                                <textarea name="posts[subtitle]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('posts.subtitle', $homepageData['posts']['subtitle'] ?? '') }}</textarea>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Button Text</label>
                                                <input type="text" 
                                                       name="posts[button_text]" 
                                                       class="form-control"
                                                       value="{{ old('posts.button_text', $homepageData['posts']['button_text'] ?? 'View All Posts') }}">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Number of Posts to Show</label>
                                                <input type="number" 
                                                       name="posts[posts_count]" 
                                                       class="form-control"
                                                       value="{{ old('posts.posts_count', $homepageData['posts']['posts_count'] ?? 3) }}"
                                                       min="1"
                                                       max="12">
                                                <div class="form-text">Number of recent posts to display (1-12)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Excerpt Length</label>
                                                <input type="number" 
                                                       name="posts[excerpt_length]" 
                                                       class="form-control"
                                                       value="{{ old('posts.excerpt_length', $homepageData['posts']['excerpt_length'] ?? 150) }}"
                                                       min="50"
                                                       max="500">
                                                <div class="form-text">Number of characters in excerpt (50-500)</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Gallery Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-camera me-2"></i>Gallery Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="gallery[enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="gallery[enabled]"
                                                       value="1"
                                                       {{ isset($homepageData['gallery']['enabled']) && $homepageData['gallery']['enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Gallery Section</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="gallery[show_button]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="gallery[show_button]"
                                                       value="1"
                                                       {{ isset($homepageData['gallery']['show_button']) && $homepageData['gallery']['show_button'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show "View Gallery" Button</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="gallery[show_overlay]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="gallery[show_overlay]"
                                                       value="1"
                                                       {{ isset($homepageData['gallery']['show_overlay']) && $homepageData['gallery']['show_overlay'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Image Overlay</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Number of Images to Show</label>
                                                <input type="number" 
                                                       name="gallery[images_count]" 
                                                       class="form-control"
                                                       value="{{ old('gallery.images_count', $homepageData['gallery']['images_count'] ?? 6) }}"
                                                       min="1"
                                                       max="12">
                                                <div class="form-text">Number of gallery images to display (1-12)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Grid Columns</label>
                                                <select name="gallery[columns]" class="form-select">
                                                    <option value="2" {{ old('gallery.columns', $homepageData['gallery']['columns'] ?? 3) == 2 ? 'selected' : '' }}>2 Columns</option>
                                                    <option value="3" {{ old('gallery.columns', $homepageData['gallery']['columns'] ?? 3) == 3 ? 'selected' : '' }}>3 Columns</option>
                                                    <option value="4" {{ old('gallery.columns', $homepageData['gallery']['columns'] ?? 3) == 4 ? 'selected' : '' }}>4 Columns</option>
                                                    <option value="6" {{ old('gallery.columns', $homepageData['gallery']['columns'] ?? 3) == 6 ? 'selected' : '' }}>6 Columns</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Section Title</label>
                                                <input type="text" 
                                                       name="gallery[title]" 
                                                       class="form-control"
                                                       value="{{ old('gallery.title', $homepageData['gallery']['title'] ?? 'Photo Gallery') }}">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Section Subtitle</label>
                                                <input type="text" 
                                                       name="gallery[subtitle]" 
                                                       class="form-control"
                                                       value="{{ old('gallery.subtitle', $homepageData['gallery']['subtitle'] ?? 'A collection of my favorite moments captured through the lens') }}">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Button Text</label>
                                                <input type="text" 
                                                       name="gallery[button_text]" 
                                                       class="form-control"
                                                       value="{{ old('gallery.button_text', $homepageData['gallery']['button_text'] ?? 'View Full Gallery') }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- About Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>About Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="about[enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="about[enabled]"
                                                       value="1"
                                                       {{ isset($homepageData['about']['enabled']) && $homepageData['about']['enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable About Section</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="about[show_image]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="about[show_image]"
                                                       value="1"
                                                       {{ isset($homepageData['about']['show_image']) && $homepageData['about']['show_image'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show About Image</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="about[show_social_icons]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="about[show_social_icons]"
                                                       value="1"
                                                       {{ isset($homepageData['about']['show_social_icons']) && $homepageData['about']['show_social_icons'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Social Icons</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">About Image URL</label>
                                                <input type="text" 
                                                       name="about[image_url]" 
                                                       class="form-control"
                                                       value="{{ old('about.image_url', $homepageData['about']['image_url'] ?? '') }}">
                                                <div class="form-text">URL for about section image</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Section Title</label>
                                                <input type="text" 
                                                       name="about[title]" 
                                                       class="form-control"
                                                       value="{{ old('about.title', $homepageData['about']['title'] ?? 'About My World') }}">
                                            </div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">About Content</label>
                                                <textarea name="about[content]" 
                                                          class="form-control" 
                                                          rows="4">{{ old('about.content', $homepageData['about']['content'] ?? '') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- SEO Meta Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-search me-2"></i>SEO Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Title</label>
                                                <input type="text" 
                                                       name="meta[meta_title]" 
                                                       class="form-control"
                                                       value="{{ old('meta.meta_title', $homepageData['meta']['meta_title'] ?? 'My World | Personal Blog & Gallery') }}">
                                                <div class="form-text">Page title for SEO (50-60 characters recommended)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Meta Keywords</label>
                                                <textarea name="meta[meta_keywords]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('meta.meta_keywords', $homepageData['meta']['meta_keywords'] ?? '') }}</textarea>
                                                <div class="form-text">Comma-separated keywords</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Description</label>
                                                <textarea name="meta[meta_description]" 
                                                          class="form-control" 
                                                          rows="4">{{ old('meta.meta_description', $homepageData['meta']['meta_description'] ?? '') }}</textarea>
                                                <div class="form-text">Page description for SEO (150-160 characters recommended)</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Reset Changes
                                </button>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-1"></i> Save Homepage Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image preview for hero background
    const heroBgInput = document.getElementById('heroBgInput');
    const heroBgPreview = document.getElementById('heroBgPreview');
    
    if (heroBgInput && heroBgPreview) {
        heroBgInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'img-fluid rounded';
                    img.style = 'max-height: 150px;';
                    
                    heroBgPreview.innerHTML = '';
                    
                    // Create image container
                    const imgContainer = document.createElement('div');
                    imgContainer.appendChild(img);
                    
                    // Add remove checkbox
                    const removeDiv = document.createElement('div');
                    removeDiv.className = 'mt-2';
                    removeDiv.innerHTML = `
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="remove_images[hero_bg]" 
                                   value="1"
                                   id="removeHeroBg">
                            <label class="form-check-label text-danger" for="removeHeroBg">
                                Remove this image
                            </label>
                        </div>
                    `;
                    
                    heroBgPreview.appendChild(imgContainer);
                    heroBgPreview.appendChild(removeDiv);
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
});
</script>
@endsection