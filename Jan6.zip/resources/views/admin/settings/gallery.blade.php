{{-- resources/views/admin/settings/gallery.blade.php --}}
@extends('admin.app')

@section('content')
<main class="app-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-gradient-primary py-3">
                        <h4 class="mb-0">
                            <i class="fas fa-images me-2"></i>Gallery Page Settings
                        </h4>
                        <small class="opacity-75">Customize your photo gallery page layout and features</small>
                    </div>
                    
                    <form action="{{ route('settings.gallery.update') }}" method="POST" id="galleryForm" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            {{-- Page Status --}}
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">Gallery Page Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                        <div class="form-text">When inactive, the gallery page will show a maintenance message.</div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Hero Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-heading me-2"></i>Hero Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Background Image</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="heroBgPreview">
                                                    @if(!empty($galleryData['hero']['hero_bg']))
                                                        <img src="{{ asset('assets/gallery/' . $galleryData['hero']['hero_bg']) }}" 
                                                             class="img-fluid rounded" 
                                                             style="max-height: 150px;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[hero_bg]" 
                                                                       value="1"
                                                                       id="removeHeroBg">
                                                                <label class="form-check-label text-danger" for="removeHeroBg">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-mountain fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No background image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="hero_bg_image" 
                                                       class="form-control" 
                                                       id="heroBgInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[hero_bg]" 
                                                       value="{{ $galleryData['hero']['hero_bg'] ?? '' }}">
                                                <div class="form-text">Recommended: 1920x600px wide image for hero background.</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="hero[show_stats]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="hero[show_stats]"
                                                       value="1"
                                                       {{ isset($galleryData['hero']['show_stats']) && $galleryData['hero']['show_stats'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Stats Counter</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Title</label>
                                            <input type="text" 
                                                   name="hero[title]" 
                                                   class="form-control"
                                                   value="{{ old('hero.title', $galleryData['hero']['title'] ?? 'My Visual Journey') }}"
                                                   placeholder="e.g., My Visual Journey">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Description</label>
                                            <textarea name="hero[description]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="Explore my world through photographs...">{{ old('hero.description', $galleryData['hero']['description'] ?? '') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Filter Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="filter[show_sort_options]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="filter[show_sort_options]"
                                                       value="1"
                                                       {{ isset($galleryData['filter']['show_sort_options']) && $galleryData['filter']['show_sort_options'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Sort Options</label>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Default Sort Option</label>
                                                <select name="filter[default_sort]" class="form-select">
                                                    <option value="newest" {{ old('filter.default_sort', $galleryData['filter']['default_sort'] ?? 'newest') == 'newest' ? 'selected' : '' }}>Newest First</option>
                                                    <option value="oldest" {{ old('filter.default_sort', $galleryData['filter']['default_sort'] ?? 'newest') == 'oldest' ? 'selected' : '' }}>Oldest First</option>
                                                    <option value="random" {{ old('filter.default_sort', $galleryData['filter']['default_sort'] ?? 'newest') == 'random' ? 'selected' : '' }}>Random</option>
                                                    <option value="name" {{ old('filter.default_sort', $galleryData['filter']['default_sort'] ?? 'newest') == 'name' ? 'selected' : '' }}>Name A-Z</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Layout Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-th-large me-2"></i>Layout Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Photos Per Page</label>
                                                <input type="number" 
                                                       name="layout[pictures_per_page]" 
                                                       class="form-control"
                                                       value="{{ old('layout.pictures_per_page', $galleryData['layout']['pictures_per_page'] ?? 12) }}"
                                                       min="1"
                                                       max="48">
                                                <div class="form-text">Number of photos to show per page (1-48)</div>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="layout[show_sidebar]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="layout[show_sidebar]"
                                                       value="1"
                                                       {{ isset($galleryData['layout']['show_sidebar']) && $galleryData['layout']['show_sidebar'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Sidebar</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="layout[masonry_enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="layout[masonry_enabled]"
                                                       value="1"
                                                       {{ isset($galleryData['layout']['masonry_enabled']) && $galleryData['layout']['masonry_enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Masonry Grid</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Grid Columns</label>
                                                <select name="layout[grid_columns]" class="form-select">
                                                    <option value="2" {{ old('layout.grid_columns', $galleryData['layout']['grid_columns'] ?? 3) == 2 ? 'selected' : '' }}>2 Columns</option>
                                                    <option value="3" {{ old('layout.grid_columns', $galleryData['layout']['grid_columns'] ?? 3) == 3 ? 'selected' : '' }}>3 Columns</option>
                                                    <option value="4" {{ old('layout.grid_columns', $galleryData['layout']['grid_columns'] ?? 3) == 4 ? 'selected' : '' }}>4 Columns</option>
                                                </select>
                                                <div class="form-text">Number of columns in gallery grid</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Sidebar Widgets --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-columns me-2"></i>Sidebar Widgets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="sidebar[show_categories_widget]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_categories_widget]"
                                                       value="1"
                                                       {{ isset($galleryData['sidebar']['show_categories_widget']) && $galleryData['sidebar']['show_categories_widget'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Categories Widget</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="sidebar[show_recent_photos_widget]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_recent_photos_widget]"
                                                       value="1"
                                                       {{ isset($galleryData['sidebar']['show_recent_photos_widget']) && $galleryData['sidebar']['show_recent_photos_widget'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Recent Photos Widget</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="sidebar[show_tips_widget]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_tips_widget]"
                                                       value="1"
                                                       {{ isset($galleryData['sidebar']['show_tips_widget']) && $galleryData['sidebar']['show_tips_widget'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Tips Widget</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Recent Photos Title</label>
                                                <input type="text" 
                                                       name="sidebar[recent_photos_title]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.recent_photos_title', $galleryData['sidebar']['recent_photos_title'] ?? 'Recent Photos') }}">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Recent Photos Count</label>
                                                <input type="number" 
                                                       name="sidebar[recent_photos_count]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.recent_photos_count', $galleryData['sidebar']['recent_photos_count'] ?? 8) }}"
                                                       min="1"
                                                       max="12">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Tips Title</label>
                                                <input type="text" 
                                                       name="sidebar[tips_title]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.tips_title', $galleryData['sidebar']['tips_title'] ?? 'Gallery Tips') }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Lightbox Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-expand me-2"></i>Lightbox Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="lightbox[enabled]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="lightbox[enabled]"
                                                       value="1"
                                                       {{ isset($galleryData['lightbox']['enabled']) && $galleryData['lightbox']['enabled'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Lightbox</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="lightbox[show_download_button]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="lightbox[show_download_button]"
                                                       value="1"
                                                       {{ isset($galleryData['lightbox']['show_download_button']) && $galleryData['lightbox']['show_download_button'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Download Button</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="lightbox[show_fullscreen_button]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="lightbox[show_fullscreen_button]"
                                                       value="1"
                                                       {{ isset($galleryData['lightbox']['show_fullscreen_button']) && $galleryData['lightbox']['show_fullscreen_button'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Fullscreen Button</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="lightbox[show_thumbnails]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="lightbox[show_thumbnails]"
                                                       value="1"
                                                       {{ isset($galleryData['lightbox']['show_thumbnails']) && $galleryData['lightbox']['show_thumbnails'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Thumbnails</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="lightbox[keyboard_navigation]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="lightbox[keyboard_navigation]"
                                                       value="1"
                                                       {{ isset($galleryData['lightbox']['keyboard_navigation']) && $galleryData['lightbox']['keyboard_navigation'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Enable Keyboard Navigation</label>
                                                <div class="form-text">Arrow keys for navigation, ESC to close</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Empty State --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-inbox me-2"></i>Empty State Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Empty State Title</label>
                                                <input type="text" 
                                                       name="empty_state[title]" 
                                                       class="form-control"
                                                       value="{{ old('empty_state.title', $galleryData['empty_state']['title'] ?? 'No Photos Found') }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Empty State Message</label>
                                                <textarea name="empty_state[message]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('empty_state.message', $galleryData['empty_state']['message'] ?? '') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Pagination --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-ellipsis-h me-2"></i>Pagination Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input type="hidden" name="pagination[show_pagination]" value="0">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="pagination[show_pagination]"
                                                       value="1"
                                                       {{ isset($galleryData['pagination']['show_pagination']) && $galleryData['pagination']['show_pagination'] == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Pagination</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- SEO Meta Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-search me-2"></i>SEO Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Title</label>
                                                <input type="text" 
                                                       name="meta[meta_title]" 
                                                       class="form-control"
                                                       value="{{ old('meta.meta_title', $galleryData['meta']['meta_title'] ?? 'My Visual Journey | Photo Gallery') }}">
                                                <div class="form-text">Page title for SEO (50-60 characters recommended)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Meta Keywords</label>
                                                <textarea name="meta[meta_keywords]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('meta.meta_keywords', $galleryData['meta']['meta_keywords'] ?? '') }}</textarea>
                                                <div class="form-text">Comma-separated keywords</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Description</label>
                                                <textarea name="meta[meta_description]" 
                                                          class="form-control" 
                                                          rows="4">{{ old('meta.meta_description', $galleryData['meta']['meta_description'] ?? '') }}</textarea>
                                                <div class="form-text">Page description for SEO (150-160 characters recommended)</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Reset Changes
                                </button>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-1"></i> Save Gallery Page Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image preview for hero background
    const heroBgInput = document.getElementById('heroBgInput');
    const heroBgPreview = document.getElementById('heroBgPreview');
    
    if (heroBgInput && heroBgPreview) {
        heroBgInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'img-fluid rounded';
                    img.style = 'max-height: 150px;';
                    
                    heroBgPreview.innerHTML = '';
                    
                    // Create image container
                    const imgContainer = document.createElement('div');
                    imgContainer.appendChild(img);
                    
                    // Add remove checkbox
                    const removeDiv = document.createElement('div');
                    removeDiv.className = 'mt-2';
                    removeDiv.innerHTML = `
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="remove_images[hero_bg]" 
                                   value="1"
                                   id="removeHeroBg">
                            <label class="form-check-label text-danger" for="removeHeroBg">
                                Remove this image
                            </label>
                        </div>
                    `;
                    
                    heroBgPreview.appendChild(imgContainer);
                    heroBgPreview.appendChild(removeDiv);
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
});
</script>
@endsection