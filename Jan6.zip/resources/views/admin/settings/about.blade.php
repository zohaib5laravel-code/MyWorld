@extends('admin.app')

@section('content')
<main class="app-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-gradient-primary py-3">
                        <h4 class="mb-0">
                            <i class="fas fa-user-circle me-2"></i>About Page Settings
                        </h4>
                        <small class="opacity-75">Customize your about page content and layout</small>
                    </div>
                    
                    <form action="{{ route('settings.about.update') }}" method="POST" id="aboutForm" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            {{-- Page Status --}}
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">About Page Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                        <div class="form-text">When inactive, the about page will show a maintenance message.</div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Hero Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-images me-2"></i>Hero Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        {{-- Hero Background Image --}}
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Background Image *</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="heroBgPreview">
                                                    @if(!empty($aboutData['images']['hero_bg']))
                                                        <img src="{{ asset('assets/about/' . $aboutData['images']['hero_bg']) }}" 
                                                             class="img-fluid rounded" 
                                                             style="max-height: 150px;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[hero_bg]" 
                                                                       value="1"
                                                                       id="removeHeroBg">
                                                                <label class="form-check-label text-danger" for="removeHeroBg">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-mountain fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No background image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="hero_bg_image" 
                                                       class="form-control" 
                                                       id="heroBgInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[hero_bg]" 
                                                       value="{{ $aboutData['images']['hero_bg'] ?? '' }}">
                                                <div class="form-text">Recommended: 1920x1080px landscape image. URL: <code>{{ !empty($aboutData['images']['hero_bg']) ? asset('assets/about/' . $aboutData['images']['hero_bg']) : 'Not set' }}</code></div>
                                            </div>
                                        </div>
                                        
                                        {{-- Profile Image (Above Name) --}}
                                        <div class="col-md-6">
                                            <label class="form-label">Profile Image *</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="profileImagePreview">
                                                    @if(!empty($aboutData['images']['profile']))
                                                        <img src="{{ asset('assets/about/' . $aboutData['images']['profile']) }}" 
                                                             class="img-fluid rounded-circle" 
                                                             style="width: 150px; height: 150px; object-fit: cover;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[profile]" 
                                                                       value="1"
                                                                       id="removeProfile">
                                                                <label class="form-check-label text-danger" for="removeProfile">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-user-circle fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No profile image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="profile_image" 
                                                       class="form-control" 
                                                       id="profileImageInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[profile]" 
                                                       value="{{ $aboutData['images']['profile'] ?? '' }}">
                                                <div class="form-text">Recommended: 500x500px square image. URL: <code>{{ !empty($aboutData['images']['profile']) ? asset('assets/about/' . $aboutData['images']['profile']) : 'Not set' }}</code></div>
                                            </div>
                                        </div>
                                        
                                        {{-- Hero Text Content --}}
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Welcome Text</label>
                                            <textarea name="hero[text]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="Welcome to my personal corner of the internet">{{ old('hero.text', $aboutData['hero']['text'] ?? 'Welcome to my personal corner of the internet') }}</textarea>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Button Text</label>
                                            <input type="text" 
                                                   name="hero[button_text]" 
                                                   class="form-control"
                                                   value="{{ old('hero.button_text', $aboutData['hero']['button_text'] ?? 'My Story') }}"
                                                   placeholder="e.g., My Story">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Personal Information Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-user me-2"></i>Personal Information</h5>
                            
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Your Name *</label>
                                            <input type="text" 
                                                   name="personalInfo[name]" 
                                                   class="form-control"
                                                   value="{{ old('personalInfo.name', $aboutData['personalInfo']['name'] ?? 'Alex') }}"
                                                   required>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Current Location</label>
                                            <input type="text" 
                                                   name="personalInfo[location]" 
                                                   class="form-control"
                                                   value="{{ old('personalInfo.location', $aboutData['personalInfo']['location'] ?? 'Somewhere Beautiful') }}"
                                                   placeholder="e.g., Somewhere Beautiful">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Bio/Introduction *</label>
                                            <textarea name="personalInfo[bio]" 
                                                      class="form-control" 
                                                      rows="3"
                                                      placeholder="A curious soul wandering through life with a camera in hand and stories in heart.">{{ old('personalInfo.bio', $aboutData['personalInfo']['bio'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Personal Mission</label>
                                            <textarea name="personalInfo[mission]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="To capture the beauty in ordinary moments and share stories that connect us all.">{{ old('personalInfo.mission', $aboutData['personalInfo']['mission'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Favorite Quote</label>
                                            <textarea name="personalInfo[quote]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="&quot;The world is full of stories waiting to be told, and I'm here to listen.&quot;">{{ old('personalInfo.quote', $aboutData['personalInfo']['quote'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Interests/Hobbies *</label>
                                            <div class="row" id="interestsContainer">
                                                @php
                                                    $interests = old('personalInfo.interests', $aboutData['personalInfo']['interests'] ?? ['Photography', 'Writing', 'Hiking', 'Coffee Brewing', 'Reading', 'Stargazing']);
                                                @endphp
                                                @foreach($interests as $index => $interest)
                                                    <div class="col-lg-4 d-flex mb-2 interest-item">
                                                        <input type="text" 
                                                               name="personalInfo[interests][{{ $index }}]"
                                                               class="form-control"
                                                               value="{{ $interest }}"
                                                               placeholder="e.g., Photography, Reading"
                                                               required>
                                                        <button type="button" class="btn btn-outline-danger remove-interest">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </div>
                                                @endforeach
                                            </div>
                                            <button type="button" id="addInterest" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-plus me-1"></i> Add Interest
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                                                  
                            {{-- Values Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-star me-2"></i>Core Values</h5>
                              
                                </div>
                                <div class="card-body">
                                    <div class="row g-3 mb-3">
                                        <div class="col-12">
                                            <label class="form-label">Section Title</label>
                                            <input type="text" 
                                                   name="values[title]" 
                                                   class="form-control"
                                                   value="{{ old('values.title', $aboutData['values']['title'] ?? 'What Guides My Journey') }}"
                                                   placeholder="e.g., What Guides My Journey">
                                        </div>
                                    </div>
                                    
                                    <div id="valuesContainer">
                                        @php
                                            $values = old('values.items', $aboutData['values']['items'] ?? [
                                                ['icon' => 'fas fa-heart', 'title' => 'Authenticity', 'description' => 'Keeping it real - no filters, no pretenses.'],
                                                ['icon' => 'fas fa-compass', 'title' => 'Curiosity', 'description' => 'Always exploring, always learning, always wondering.'],
                                                ['icon' => 'fas fa-hands', 'title' => 'Connection', 'description' => 'Building bridges through shared stories and experiences.'],
                                                ['icon' => 'fas fa-sun', 'title' => 'Positivity', 'description' => 'Finding light even in challenging moments.']
                                            ]);
                                        @endphp
                                        @foreach($values as $index => $value)
                                            <div class="value-item card mb-3" data-index="{{ $index }}">
                                                <div class="card-body">
                                                    <div class="row g-3">
                                                        <div class="col-md-2">
                                                            <label class="form-label small">Icon Class *</label>
                                                            <input type="text" 
                                                                   name="values[items][{{ $index }}][icon]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $value['icon'] ?? '' }}"
                                                                   placeholder="fas fa-heart"
                                                                   required>
                                                            <div class="form-text small">Font Awesome class</div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label small">Title *</label>
                                                            <input type="text" 
                                                                   name="values[items][{{ $index }}][title]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $value['title'] ?? '' }}"
                                                                   placeholder="e.g., Authenticity"
                                                                   required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label small">Description *</label>
                                                            <textarea name="values[items][{{ $index }}][description]"
                                                                      class="form-control form-control-sm"
                                                                      rows="2"
                                                                      placeholder="Description of this value"
                                                                      required>{{ $value['description'] ?? '' }}</textarea>
                                                        </div>
                                                        <div class="col-md-1  ">
                                                            <button type="button" class="btn btn-sm btn-outline-danger remove-value">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button type="button" id="addValue" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-plus me-1"></i> Add Value
                                    </button>
                                </div>
                            </div>
                            
                            {{-- Journey Timeline --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-road me-2"></i>Journey Timeline</h5>
                                   
                                </div>
                                <div class="card-body">
                                    <div class="row g-3 mb-3">
                                        <div class="col-12">
                                            <label class="form-label">Section Title</label>
                                            <input type="text" 
                                                   name="journey[title]" 
                                                   class="form-control"
                                                   value="{{ old('journey.title', $aboutData['journey']['title'] ?? 'My Journey So Far') }}"
                                                   placeholder="e.g., My Journey So Far">
                                        </div>
                                    </div>
                                    
                                    <div id="journeyContainer">
                                        @php
                                            $journeyItems = old('journey.items', $aboutData['journey']['items'] ?? [
                                                ['year' => '2018', 'title' => 'The First Click', 'description' => 'Started documenting my daily life with a simple point-and-shoot camera.'],
                                                ['year' => '2019', 'title' => 'Finding My Voice', 'description' => 'Began writing alongside photos, discovering the power of combined storytelling.'],
                                                ['year' => '2020', 'title' => 'Going Digital', 'description' => 'Created My World blog to share my journey beyond social media.'],
                                                ['year' => '2021', 'title' => 'First Solo Trip', 'description' => 'Traveled across the country, documenting every moment of self-discovery.'],
                                                ['year' => '2022', 'title' => 'Finding Community', 'description' => 'Connected with fellow creators and started meaningful collaborations.'],
                                                ['year' => '2023', 'title' => 'New Perspective', 'description' => 'Redesigned My World to focus on authentic, meaningful storytelling.']
                                            ]);
                                        @endphp
                                        @foreach($journeyItems as $index => $milestone)
                                            <div class="journey-item card mb-3" data-index="{{ $index }}">
                                                <div class="card-body">
                                                    <div class="row g-3">
                                                        <div class="col-md-2">
                                                            <label class="form-label small">Year *</label>
                                                            <input type="text" 
                                                                   name="journey[items][{{ $index }}][year]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $milestone['year'] ?? '' }}"
                                                                   placeholder="e.g., 2020"
                                                                   required>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label small">Title *</label>
                                                            <input type="text" 
                                                                   name="journey[items][{{ $index }}][title]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $milestone['title'] ?? '' }}"
                                                                   placeholder="e.g., First Solo Trip"
                                                                   required>
                                                        </div>
                                                        <div class="col-md-5">
                                                            <label class="form-label small">Description *</label>
                                                            <textarea name="journey[items][{{ $index }}][description]"
                                                                      class="form-control form-control-sm"
                                                                      rows="2"
                                                                      placeholder="Brief description"
                                                                      required>{{ $milestone['description'] ?? '' }}</textarea>
                                                        </div>
                                                        <div class="col-md-1 ">
                                                            <button type="button" class="btn btn-sm btn-outline-danger remove-journey">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button type="button" id="addJourney" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-plus me-1"></i> Add Milestone
                                    </button>
                                </div>
                            </div>
                            
                            {{-- Favorites Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-heart me-2"></i>My Favorites</h5>
                               
                                </div>
                                <div class="card-body">
                                    <div class="row g-3 mb-3">
                                        <div class="col-12">
                                            <label class="form-label">Section Title</label>
                                            <input type="text" 
                                                   name="favorites[title]" 
                                                   class="form-control"
                                                   value="{{ old('favorites.title', $aboutData['favorites']['title'] ?? 'My Favorites') }}"
                                                   placeholder="e.g., My Favorites">
                                        </div>
                                    </div>
                                    
                                    <div id="favoritesContainer">
                                        @php
                                            $favorites = old('favorites.items', $aboutData['favorites']['items'] ?? [
                                                ['type' => 'Camera Gear', 'items' => ['Canon EOS R5', '24-70mm Lens', 'Tripod', 'Polarizing Filters']],
                                                ['type' => 'Travel Essentials', 'items' => ['Journal', 'Coffee Kit', 'Comfortable Shoes', 'Portable Charger']],
                                                ['type' => 'Creative Tools', 'items' => ['Moleskine Notebook', 'Fountain Pen', 'iPad Pro', 'Noise-canceling Headphones']],
                                                ['type' => 'Reading List', 'items' => ['Into the Wild', 'The Alchemist', 'Wild', 'The Photographer\'s Eye']]
                                            ]);
                                        @endphp
                                        @foreach($favorites as $index => $favorite)
                                            <div class="favorite-item card mb-3" data-index="{{ $index }}">
                                                <div class="card-body">
                                                    <div class="row g-3">
                                                        <div class="col-md-3">
                                                            <label class="form-label small">Category *</label>
                                                            <input type="text" 
                                                                   name="favorites[items][{{ $index }}][type]"
                                                                   class="form-control form-control-sm"
                                                                   value="{{ $favorite['type'] ?? '' }}"
                                                                   placeholder="e.g., Camera Gear"
                                                                   required>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <label class="form-label small">Items (one per line) *</label>
                                                            <textarea name="favorites[items][{{ $index }}][items]"
                                                                      class="form-control form-control-sm"
                                                                      rows="3"
                                                                      placeholder="One item per line"
                                                                      required>{{ isset($favorite['items']) ? (is_array($favorite['items']) ? implode("\n", $favorite['items']) : $favorite['items']) : '' }}</textarea>
                                                            <div class="form-text small">Enter each item on a new line</div>
                                                        </div>
                                                        <div class="col-md-1 ">
                                                            <button type="button" class="btn btn-sm btn-outline-danger remove-favorite">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <button type="button" id="addFavorite" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-plus me-1"></i> Add Category
                                    </button>
                                </div>
                            </div>
                            
                            {{-- Contact Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-envelope me-2"></i>Contact Section</h5>
                                
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label">Section Title</label>
                                            <input type="text" 
                                                   name="contact[title]" 
                                                   class="form-control"
                                                   value="{{ old('contact.title', $aboutData['contact']['title'] ?? 'Let\'s Connect') }}"
                                                   placeholder="e.g., Let's Connect">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Description</label>
                                            <textarea name="contact[description]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="I love connecting with fellow travelers, photographers, and story lovers. Feel free to reach out!">{{ old('contact.description', $aboutData['contact']['description'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <label class="form-label">Instagram URL</label>
                                            <input type="url" 
                                                   name="contact[social][instagram]" 
                                                   class="form-control"
                                                   value="{{ old('contact.social.instagram', $aboutData['contact']['social']['instagram'] ?? '#') }}"
                                                   placeholder="https://instagram.com/username">
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <label class="form-label">Twitter URL</label>
                                            <input type="url" 
                                                   name="contact[social][twitter]" 
                                                   class="form-control"
                                                   value="{{ old('contact.social.twitter', $aboutData['contact']['social']['twitter'] ?? '#') }}"
                                                   placeholder="https://twitter.com/username">
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <label class="form-label">Pinterest URL</label>
                                            <input type="url" 
                                                   name="contact[social][pinterest]" 
                                                   class="form-control"
                                                   value="{{ old('contact.social.pinterest', $aboutData['contact']['social']['pinterest'] ?? '#') }}"
                                                   placeholder="https://pinterest.com/username">
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <label class="form-label">Email Address</label>
                                            <input type="email" 
                                                   name="contact[social][email]" 
                                                   class="form-control"
                                                   value="{{ old('contact.social.email', $aboutData['contact']['social']['email'] ?? '#') }}"
                                                   placeholder="mailto:email@example.com">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Section Visibility Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-eye me-2"></i>Section Visibility</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_hero_images]"
                                                       value="1"
                                                       {{ old('settings.show_hero_images', $aboutData['settings']['show_hero_images'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Hero Images</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_personal_info]"
                                                       value="1"
                                                       {{ old('settings.show_personal_info', $aboutData['settings']['show_personal_info'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Personal Information</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_values]"
                                                       value="1"
                                                       {{ old('settings.show_values', $aboutData['settings']['show_values'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Values Section</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                           
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_journey]"
                                                       value="1"
                                                       {{ old('settings.show_journey', $aboutData['settings']['show_journey'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Journey Timeline</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_favorites]"
                                                       value="1"
                                                       {{ old('settings.show_favorites', $aboutData['settings']['show_favorites'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Favorites Section</label>
                                            </div>
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="settings[show_contact]"
                                                       value="1"
                                                       {{ old('settings.show_contact', $aboutData['settings']['show_contact'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Contact Section</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Reset Changes
                                </button>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-1"></i> Save About Page Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection

@section('styles')
<style>
    .image-upload-wrapper {
        margin-bottom: 1rem;
    }
    
    .image-preview {
        border: 2px dashed #dee2e6;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        background: #f8f9fa;
        min-height: 200px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    
    .no-image-placeholder {
        color: #6c757d;
    }
    
    .section-card {
        transition: all 0.3s ease;
    }
    
    .section-toggle:not(:checked) ~ .card-body {
        opacity: 0.6;
        pointer-events: none;
    }
    
    .interest-item, .value-item, .journey-item, .favorite-item {
        transition: all 0.2s ease;
    }
    
    .interest-item:hover, .value-item:hover, .journey-item:hover, .favorite-item:hover {
        background-color: #f8f9fa;
        transform: translateX(2px);
    }
    
    .form-text code {
        background: #f1f3f5;
        padding: 2px 4px;
        border-radius: 3px;
        font-size: 0.9em;
        color: #495057;
    }
</style>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image preview functionality
    function setupImagePreview(inputId, previewId, isCircle = false) {
        const input = document.getElementById(inputId);
        const preview = document.getElementById(previewId);
        
        if (input && preview) {
            input.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = isCircle ? 'img-fluid rounded-circle' : 'img-fluid rounded';
                        img.style = isCircle ? 'width: 150px; height: 150px; object-fit: cover;' : 'max-height: 150px;';
                        
                        preview.innerHTML = '';
                        
                        // Create image container
                        const imgContainer = document.createElement('div');
                        imgContainer.appendChild(img);
                        
                        // Add remove checkbox
                        const removeDiv = document.createElement('div');
                        removeDiv.className = 'mt-2';
                        removeDiv.innerHTML = `
                            <div class="form-check">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="remove_images[${inputId.replace('Input', '')}]" 
                                       value="1"
                                       id="remove${inputId}">
                                <label class="form-check-label text-danger" for="remove${inputId}">
                                    Remove this image
                                </label>
                            </div>
                        `;
                        
                        preview.appendChild(imgContainer);
                        preview.appendChild(removeDiv);
                    };
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
        }
    }
    
    // Set up image previews
    setupImagePreview('heroBgInput', 'heroBgPreview', false);
    setupImagePreview('profileImageInput', 'profileImagePreview', true);
    
    // Section toggling
    document.querySelectorAll('.section-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const cardBody = this.closest('.section-card').querySelector('.card-body');
            if (this.checked) {
                cardBody.style.opacity = '1';
                cardBody.style.pointerEvents = 'auto';
            } else {
                cardBody.style.opacity = '0.6';
                cardBody.style.pointerEvents = 'none';
            }
        });
        
        // Initialize toggle state
        toggle.dispatchEvent(new Event('change'));
    });
    
    // Interests Management
    let interestIndex = {{ count($aboutData['personalInfo']['interests'] ?? []) }};
    document.getElementById('addInterest').addEventListener('click', function() {
        const container = document.getElementById('interestsContainer');
        const html = `
            <div class="col-lg-4 d-flex mb-2 interest-item">
                <input type="text" 
                       name="personalInfo[interests][${interestIndex}]"
                       class="form-control"
                       placeholder="e.g., Photography, Reading"
                       required>
                <button type="button" class="btn btn-outline-danger remove-interest">
                    <i class="fas fa-times"></i>
                </button>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        interestIndex++;
    });
    
    document.getElementById('interestsContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-interest')) {
            e.target.closest('.interest-item').remove();
        }
    });
    
    // Journey Management
    let journeyIndex = {{ count($aboutData['journey']['items'] ?? []) }};
    document.getElementById('addJourney').addEventListener('click', function() {
        const container = document.getElementById('journeyContainer');
        const html = `
            <div class="journey-item card mb-3" data-index="${journeyIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label class="form-label small">Year *</label>
                            <input type="text" 
                                   name="journey[items][${journeyIndex}][year]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., 2020"
                                   required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small">Title *</label>
                            <input type="text" 
                                   name="journey[items][${journeyIndex}][title]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., First Solo Trip"
                                   required>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small">Description *</label>
                            <textarea name="journey[items][${journeyIndex}][description]"
                                      class="form-control form-control-sm"
                                      rows="2"
                                      placeholder="Brief description"
                                      required></textarea>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-journey">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        journeyIndex++;
    });
    
    document.getElementById('journeyContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-journey')) {
            e.target.closest('.journey-item').remove();
            reindexItems('journeyContainer', 'journey', 'items');
        }
    });
    
    // Values Management
    let valueIndex = {{ count($aboutData['values']['items'] ?? []) }};
    document.getElementById('addValue').addEventListener('click', function() {
        const container = document.getElementById('valuesContainer');
        const html = `
            <div class="value-item card mb-3" data-index="${valueIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label class="form-label small">Icon Class *</label>
                            <input type="text" 
                                   name="values[items][${valueIndex}][icon]"
                                   class="form-control form-control-sm"
                                   placeholder="fas fa-heart"
                                   required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small">Title *</label>
                            <input type="text" 
                                   name="values[items][${valueIndex}][title]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., Authenticity"
                                   required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Description *</label>
                            <textarea name="values[items][${valueIndex}][description]"
                                      class="form-control form-control-sm"
                                      rows="2"
                                      placeholder="Description of this value"
                                      required></textarea>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-value">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        valueIndex++;
    });
    
    document.getElementById('valuesContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-value')) {
            e.target.closest('.value-item').remove();
            reindexItems('valuesContainer', 'values', 'items');
        }
    });
    
    // Favorites Management
    let favoriteIndex = {{ count($aboutData['favorites']['items'] ?? []) }};
    document.getElementById('addFavorite').addEventListener('click', function() {
        const container = document.getElementById('favoritesContainer');
        const html = `
            <div class="favorite-item card mb-3" data-index="${favoriteIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small">Category *</label>
                            <input type="text" 
                                   name="favorites[items][${favoriteIndex}][type]"
                                   class="form-control form-control-sm"
                                   placeholder="e.g., Camera Gear"
                                   required>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label small">Items (one per line) *</label>
                            <textarea name="favorites[items][${favoriteIndex}][items]"
                                      class="form-control form-control-sm"
                                      rows="3"
                                      placeholder="One item per line"
                                      required></textarea>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-favorite">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        favoriteIndex++;
    });
    
    document.getElementById('favoritesContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-favorite')) {
            e.target.closest('.favorite-item').remove();
            reindexItems('favoritesContainer', 'favorites', 'items');
        }
    });
    
    function reindexItems(containerId, prefix, subPrefix = '') {
        const container = document.getElementById(containerId);
        const items = container.querySelectorAll(`.${prefix}-item`);
        items.forEach((item, index) => {
            item.dataset.index = index;
            const inputs = item.querySelectorAll('input, textarea, select');
            inputs.forEach(input => {
                const name = input.name.replace(
                    new RegExp(`${prefix}\\[${subPrefix}\\]\\[\\d+\\]`), 
                    `${prefix}[${subPrefix}][${index}]`
                );
                input.name = name;
            });
        });
        window[prefix + 'Index'] = items.length;
    }
});
</script>
@endsection