<form action="{{ route('settings.menu.update') }}" method="POST" id="menuForm" enctype="multipart/form-data">
    @csrf
    
    <div class="card-body flex-grow-1 overflow-auto section-content">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                <ul class="mb-0 ps-3">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        {{-- Page Status --}}
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Menu Status</label>
                    <select name="status" class="form-select" required>
                        <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                    </select>
                    <div class="form-text">When inactive, the default menu will be shown.</div>
                </div>
            </div>
        </div>
        
        {{-- Logo/Brand Settings --}}
        <div class="section-card card border mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-image me-2"></i>Logo & Brand Settings</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Logo Type</label>
                        <select name="logo[type]" class="form-select">
                            <option value="text" {{ old('logo.type', $menuData['logo']['type'] ?? 'text') == 'text' ? 'selected' : '' }}>Text Only</option>
                            <option value="image" {{ old('logo.type', $menuData['logo']['type'] ?? 'text') == 'image' ? 'selected' : '' }}>Image Only</option>
                            <option value="both" {{ old('logo.type', $menuData['logo']['type'] ?? 'text') == 'both' ? 'selected' : '' }}>Text & Image</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Logo Text</label>
                        <input type="text" 
                               name="logo[text]" 
                               class="form-control"
                               value="{{ old('logo.text', $menuData['logo']['text'] ?? 'My World') }}">
                    </div>
                                                               
                    
                    <div class="col-12">
                        <label class="form-label">Logo Image</label>
                        <div class="image-upload-wrapper">
                            <div class="image-preview mb-2" id="logoPreview">
                                @if(!empty($menuData['logo']['image']))
                                    <img src="{{ asset('assets/menu/' . $menuData['logo']['image']) }}" 
                                         class="img-fluid rounded" 
                                         style="max-height: 150px;">
                                    <div class="mt-2">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="checkbox" 
                                                   name="remove_images[logo]" 
                                                   value="1"
                                                   id="removeLogo">
                                            <label class="form-check-label text-danger" for="removeLogo">
                                                Remove this image
                                            </label>
                                        </div>
                                    </div>
                                @else
                                    <div class="no-image-placeholder">
                                        <i class="fas fa-image fa-3x text-muted"></i>
                                        <p class="mt-2 text-muted">No logo image selected</p>
                                    </div>
                                @endif
                            </div>
                            <input type="file" 
                                   name="logo_image" 
                                   class="form-control" 
                                   id="logoInput"
                                   accept="image/*">
                            <input type="hidden" 
                                   name="current_images[logo]" 
                                   value="{{ $menuData['logo']['image'] ?? '' }}">
                            <div class="form-text">Recommended: Transparent PNG logo, max height 40px</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        {{-- Menu Items --}}
        <div class="section-card card border mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Menu Items</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6>Manage Navigation Items</h6>
                            <button type="button" class="btn btn-sm btn-outline-primary" id="addMenuItem">
                                <i class="fas fa-plus me-1"></i> Add Item
                            </button>
                        </div>
                    </div>
                </div>
                
                <div id="menuItemsContainer">
                    @php
                        $items = old('items', $menuData['items'] ?? $this->getDefaultMenuData()['items']);
                    @endphp
                    
                    @foreach($items as $index => $item)
                    <div class="menu-item card mb-3" data-index="{{ $index }}">
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label small">Label *</label>
                                    <input type="text" 
                                           name="items[{{ $index }}][label]"
                                           class="form-control form-control-sm"
                                           value="{{ $item['label'] ?? '' }}"
                                           placeholder="Home"
                                           required>
                                </div>
                                
                                <div class="col-md-3">
                                    <label class="form-label small">URL *</label>
                                    <input type="text" 
                                           name="items[{{ $index }}][url]"
                                           class="form-control form-control-sm"
                                           value="{{ $item['url'] ?? '' }}"
                                           placeholder="/"
                                           required>
                                </div>
                                
                                <div class="col-md-2">
                                    <label class="form-label small">Route Name</label>
                                    <input type="text" 
                                           name="items[{{ $index }}][route]"
                                           class="form-control form-control-sm"
                                           value="{{ $item['route'] ?? '' }}"
                                           placeholder="frontend.home">
                                </div>
                                
                            
                                
                                <div class="col-md-2">
                                    <div class="form-check form-switch mt-4">
                                        <input type="hidden" name="items[{{ $index }}][enabled]" value="0">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               name="items[{{ $index }}][enabled]"
                                               value="1"
                                               {{ isset($item['enabled']) && $item['enabled'] == 1 ? 'checked' : '' }}>
                                        <label class="form-check-label small">Enabled</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-check form-switch mt-4">
                                        <input type="hidden" name="items[{{ $index }}][new_tab]" value="0">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               name="items[{{ $index }}][new_tab]"
                                               value="1"
                                               {{ isset($item['new_tab']) && $item['new_tab'] == 1 ? 'checked' : '' }}>
                                        <label class="form-check-label small">New Tab</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-sm btn-outline-danger remove-menu-item">
                                        <i class="fas fa-trash me-1"></i> Remove
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                
            </div>
        </div>
    </div>
    
    <div class="card-footer bg-light border-top py-3">
        <div class="d-flex justify-content-between">
            <button type="reset" class="btn btn-outline-secondary">
                <i class="fas fa-undo me-1"></i> Reset Changes
            </button>
            <button type="submit" class="btn btn-primary px-4">
                <i class="fas fa-save me-1"></i> Save Menu Settings
            </button>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image preview for logo
    const logoInput = document.getElementById('logoInput');
    const logoPreview = document.getElementById('logoPreview');
    
    if (logoInput && logoPreview) {
        logoInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'img-fluid rounded';
                    img.style = 'max-height: 150px;';
                    
                    logoPreview.innerHTML = '';
                    
                    // Create image container
                    const imgContainer = document.createElement('div');
                    imgContainer.appendChild(img);
                    
                    // Add remove checkbox
                    const removeDiv = document.createElement('div');
                    removeDiv.className = 'mt-2';
                    removeDiv.innerHTML = `
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="remove_images[logo]" 
                                   value="1"
                                   id="removeLogo">
                            <label class="form-check-label text-danger" for="removeLogo">
                                Remove this image
                            </label>
                        </div>
                    `;
                    
                    logoPreview.appendChild(imgContainer);
                    logoPreview.appendChild(removeDiv);
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
    
    // Menu Items Management
    let menuItemIndex = {{ count($menuData['items'] ?? []) }};
    
    document.getElementById('addMenuItem').addEventListener('click', function() {
        const container = document.getElementById('menuItemsContainer');
        const html = `
            <div class="menu-item card mb-3" data-index="${menuItemIndex}">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small">Label *</label>
                            <input type="text" 
                                   name="items[${menuItemIndex}][label]"
                                   class="form-control form-control-sm"
                                   placeholder="Home"
                                   required>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label small">URL *</label>
                            <input type="text" 
                                   name="items[${menuItemIndex}][url]"
                                   class="form-control form-control-sm"
                                   placeholder="/"
                                   required>
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label small">Route Name</label>
                            <input type="text" 
                                   name="items[${menuItemIndex}][route]"
                                   class="form-control form-control-sm"
                                   placeholder="frontend.home">
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label small">Icon Class</label>
                            <input type="text" 
                                   name="items[${menuItemIndex}][icon]"
                                   class="form-control form-control-sm"
                                   placeholder="fas fa-home">
                        </div>
                        
                        <div class="col-md-1">
                            <div class="form-check form-switch mt-4">
                                <input type="hidden" name="items[${menuItemIndex}][enabled]" value="0">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="items[${menuItemIndex}][enabled]"
                                       value="1"
                                       checked>
                                <label class="form-check-label small">Enabled</label>
                            </div>
                        </div>
                        
                        <div class="col-md-1">
                            <div class="form-check form-switch mt-4">
                                <input type="hidden" name="items[${menuItemIndex}][new_tab]" value="0">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="items[${menuItemIndex}][new_tab]"
                                       value="1">
                                <label class="form-check-label small">New Tab</label>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <button type="button" class="btn btn-sm btn-outline-danger remove-menu-item">
                                <i class="fas fa-trash me-1"></i> Remove
                            </button>
                        </div>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
        menuItemIndex++;
    });
    
    document.getElementById('menuItemsContainer').addEventListener('click', function(e) {
        if (e.target.closest('.remove-menu-item')) {
            e.target.closest('.menu-item').remove();
        }
    });
});
</script>