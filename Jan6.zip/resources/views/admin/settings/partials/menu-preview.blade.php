{{-- resources/views/admin/settings/partials/menu-preview.blade.php --}}
<div class="menu-preview">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            {{-- Logo --}}
            <a class="navbar-brand" href="#">
                @if(!empty($menuData['logo']['image']))
                    <img src="{{ asset('assets/menu/' . $menuData['logo']['image']) }}" 
                         alt="{{ $menuData['logo']['text'] ?? 'Logo' }}"
                         height="40"
                         class="d-inline-block align-text-top me-2">
                @endif
                <span class="logo-text">{{ $menuData['logo']['text'] ?? 'My World' }}</span>
            </a>
            
            {{-- Menu Items --}}
            <div class="collapse navbar-collapse" id="previewNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    @foreach($menuData['items'] ?? [] as $item)
                        @if($item['enabled'] ?? true)
                            <li class="nav-item">
                                <a class="nav-link" 
                                   href="{{ $item['url'] ?? '#' }}"
                                   {{ $item['new_tab'] ?? false ? 'target="_blank"' : '' }}>
                                    @if($item['icon'] ?? false)
                                        <i class="{{ $item['icon'] }} me-1"></i>
                                    @endif
                                    {{ $item['label'] ?? 'Menu Item' }}
                                </a>
                            </li>
                        @endif
                    @endforeach
                </ul>
            </div>
        </div>
    </nav>
    
    {{-- Preview Note --}}
    <div class="alert alert-info mt-3 mb-0">
        <i class="bi bi-info-circle me-2"></i>
        This is a preview of how your menu will appear. Actual colors and styling may vary based on your theme.
    </div>
</div>