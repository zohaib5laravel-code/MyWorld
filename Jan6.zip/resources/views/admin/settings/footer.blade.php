@extends('admin/app')

@section('content')
<main class="app-main d-flex flex-column">
    <div class="container-fluid flex-grow-1">
        <div class="row h-100">
            {{-- Settings Form Section --}}
            <div class="col-lg-12">
                <div class="card h-100 mb-4 shadow-sm">
                    <div class="card-header bg-gradient-primary  d-flex justify-content-between align-items-center py-3">
                        <div>
                            <h4 class="mb-0"><i class="bi bi-layout-text-window-reverse me-2"></i>Footer Settings</h4>
                            <small class="opacity-75">Configure what to show and how to style your website footer</small>
                        </div>
                        <div class="form-check form-switch mb-0 ms-auto">
                            <input class="form-check-input" type="checkbox" role="switch" id="livePreviewToggle" checked data-bs-toggle="tooltip" title="Toggle Live Preview">
                            <label class="form-check-label " for="livePreviewToggle">Live Preview</label>
                        </div>
                    </div>
                    
                    <form action="{{ route('settings.footer.update') }}" method="POST" id="footerForm" class="h-100 d-flex flex-column">
                        @csrf
                        
                        <div class="card-body flex-grow-1 overflow-auto" style="max-height: 60vh;">
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="bi bi-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif

                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif

                            <div class="row g-4">
                                {{-- Status --}}
                                <div class="col-md-12 col-lg-6">
                                    <div class="settings-card card border h-100">
                                        <div class="card-header bg-light">
                                            <h6 class="mb-0"><i class="bi bi-toggle-on me-2"></i>About</h6>
                                        </div>
                                        <div class="card-body">
                                          <div class="d-flex justify-content-between">
                                              <div class="mb-3 col-lg-5">
                                                <label class="form-label">Footer Status</label>
                                                <select name="status" class="form-select" required>
                                                    <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                                    <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                                </select>
                                            </div>
                                              <div class="mb-3 col-lg-6">
                                                <label class="form-label">Title</label>
                                                <input type="text" name="footer[about][title]" 
                                                       class="form-control form-control-sm" 
                                                       placeholder="e.g., My Company"
                                                       value="{{ old('footer.about.title', $footer['about']['title'] ?? '') }}">
                                            </div>
                                          </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Description</label>
                                                <textarea name="footer[about][description]" 
                                                          class="form-control form-control-sm" 
                                                          rows="2"
                                                          placeholder="Brief description about your company">{{ old('footer.about.description', $footer['about']['description'] ?? '') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- ABOUT SECTION --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="about">
                                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><i class="bi bi-info-circle me-2"></i>Social Links</h6>
                                            
                                        </div>
                                        <div class="card-body section-content">
                                          
                                            
                                            <div class="mb-0">
                                                <label class="form-label mb-2"> Links</label>
                                                <div class="social-inputs">
                                                    @foreach($social_platforms as $platform)
                                                        <div class="input-group input-group-sm mb-2">
                                                            <span class="input-group-text bg-light">
                                                                <i class="bi bi-{{ $platform }} text-primary"></i>
                                                            </span>
                                                            <input type="text" 
                                                                   name="footer[about][social][{{ $platform }}]"
                                                                   class="form-control"
                                                                   placeholder="{{ ucfirst($platform) }} URL"
                                                                   value="{{ old("footer.about.social.$platform", $footer['about']['social'][$platform] ?? '') }}">
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- QUICK LINKS --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="quick-links">
                                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><i class="bi bi-link-45deg me-2"></i>Quick Links</h6>
                                            
                                        </div>
                                        <div class="card-body section-content">
                                            <div class="mb-3">
                                                <label class="form-label mb-2">Links</label>
                                                <div id="quickLinksContainer" class="mb-3">
                                                    @foreach(old('footer.quick_links', $footer['quick_links'] ?? []) as $index => $link)
                                                        <div class="link-item mb-2" data-index="{{ $index }}">
                                                            <div class="d-flex gap-2 align-items-start">
                                                                <div class="flex-grow-1">
                                                                    <div class="row g-1">
                                                                        <div class="col-6">
                                                                            <input type="text" 
                                                                                   name="footer[quick_links][{{ $index }}][label]"
                                                                                   class="form-control form-control-sm"
                                                                                   placeholder="Label"
                                                                                   value="{{ $link['label'] ?? '' }}"
                                                                                   required>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <input type="text" 
                                                                                   name="footer[quick_links][{{ $index }}][url]"
                                                                                   class="form-control form-control-sm"
                                                                                   placeholder="URL"
                                                                                   value="{{ $link['url'] ?? '' }}">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <button type="button" class="btn btn-sm btn-outline-danger remove-link">
                                                                    <i class="bi bi-trash"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                                
                                                <button type="button" id="addQuickLink" class="btn btn-sm btn-outline-primary w-100">
                                                    <i class="bi bi-plus-circle me-1"></i> Add Link
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- CONTACT INFO --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="contact">
                                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><i class="bi bi-envelope-paper me-2"></i>Contact</h6>
                                            
                                        </div>
                                        <div class="card-body section-content">
                                            <div class="mb-3">
                                                <label class="form-label">Email</label>
                                                <input type="email" 
                                                       name="footer[contact][email]"
                                                       class="form-control form-control-sm"
                                                       placeholder="contact@example.com"
                                                       value="{{ old('footer.contact.email', $footer['contact']['email'] ?? '') }}">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Phone</label>
                                                <input type="text" 
                                                       name="footer[contact][phone]"
                                                       class="form-control form-control-sm"
                                                       placeholder="+1 (555) 123-4567"
                                                       value="{{ old('footer.contact.phone', $footer['contact']['phone'] ?? '') }}">
                                            </div>
                                            <div class="mb-0">
                                                <label class="form-label">Address</label>
                                                <textarea name="footer[contact][address]"
                                                          class="form-control form-control-sm"
                                                          rows="2"
                                                          placeholder="Full address">{{ old('footer.contact.address', $footer['contact']['address'] ?? '') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- NEWSLETTER --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="newsletter">
                                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><i class="bi bi-megaphone me-2"></i>Newsletter</h6>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input section-toggle" 
                                                       type="checkbox" 
                                                       name="footer[newsletter][enabled]"
                                                       value="1"
                                                       {{ old('footer.newsletter.enabled', $footer['newsletter']['enabled'] ?? false) ? 'checked' : '' }}>
                                            </div>
                                        </div>
                                        <div class="card-body section-content">
                                            <div class="mb-3">
                                                <label class="form-label">Placeholder Text</label>
                                                <input type="text" 
                                                       name="footer[newsletter][placeholder]"
                                                       class="form-control form-control-sm"
                                                       placeholder="e.g., Enter your email"
                                                       value="{{ old('footer.newsletter.placeholder', $footer['newsletter']['placeholder'] ?? '') }}">
                                            </div>
                                            <div class="mb-0">
                                                <label class="form-label">Button Text</label>
                                                <input type="text" 
                                                       name="footer[newsletter][button_text]"
                                                       class="form-control form-control-sm"
                                                       placeholder="e.g., Subscribe"
                                                       value="{{ old('footer.newsletter.button_text', $footer['newsletter']['button_text'] ?? '') }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- STYLING --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="style">
                                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0"><i class="bi bi-palette me-2"></i>Styling</h6>
                                            
                                        </div>
                                        <div class="card-body section-content">
                                            <div class="mb-3">
                                                <label class="form-label small">Background</label>
                                                <input type="text" 
                                                       name="footer[style][bg_class]"
                                                       class="form-control form-control-sm"
                                                       placeholder="bg-dark, bg-primary, etc."
                                                       value="{{ old('footer.style.bg_class', $footer['style']['bg_class'] ?? 'bg-dark') }}">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label small">Text Color</label>
                                                <input type="text" 
                                                       name="footer[style][text_class]"
                                                       class="form-control form-control-sm"
                                                       placeholder="text-light, text-white, etc."
                                                       value="{{ old('footer.style.text_class', $footer['style']['text_class'] ?? 'text-light') }}">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label small">Link Style</label>
                                                <input type="text" 
                                                       name="footer[style][link_class]"
                                                       class="form-control form-control-sm"
                                                       placeholder="Link classes"
                                                       value="{{ old('footer.style.link_class', $footer['style']['link_class'] ?? 'text-light text-decoration-none') }}">
                                            </div>
                                            <div class="mb-0">
                                                <label class="form-label small">Icon Style</label>
                                                <input type="text" 
                                                       name="footer[style][icon_class]"
                                                       class="form-control form-control-sm"
                                                       placeholder="Icon classes"
                                                       value="{{ old('footer.style.icon_class', $footer['style']['icon_class'] ?? 'text-light') }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- FOOTER TEXT --}}
                                <div class="col-md-6 col-lg-3">
                                    <div class="settings-card card border h-100" data-section="text">
                                        <div class="card-header bg-light">
                                            <h6 class="mb-0"><i class="bi bi-type me-2"></i>Footer Text</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label class="form-label small">Copyright</label>
                                                <input type="text" 
                                                       name="footer[copyright]"
                                                       class="form-control form-control-sm"
                                                       placeholder="© 2024 My Company"
                                                       value="{{ old('footer.copyright', $footer['copyright'] ?? '') }}">
                                            </div>
                                            <div class="mb-0">
                                                <label class="form-label small">Credit</label>
                                                <textarea name="footer[credit]"
                                                          class="form-control form-control-sm"
                                                          rows="2"
                                                          placeholder="Built with love...">{{ old('footer.credit', $footer['credit'] ?? '') }}</textarea>
                                                <div class="form-text smaller">HTML allowed for icons/links</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <button type="reset" class="btn btn-outline-secondary btn-sm">
                                        <i class="bi bi-arrow-clockwise me-1"></i> Reset
                                    </button>
                                    <button type="button" id="toggleAllSections" class="btn btn-outline-info btn-sm ms-2">
                                        <i class="bi bi-layers me-1"></i> Toggle All
                                    </button>
                                </div>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="bi bi-save me-1"></i> Save Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- Fixed Footer Preview at Bottom --}}
    <div class="preview-container mt-4" id="previewContainer">
        <div class="container-fluid">
           <div class="card-body p-0" id="previewContent">
                    <div id="footerPreview" class="p-4" >
                        @include('admin.settings.footer-preview', [
                            'footer' => $footer, 
                            'status' => $status,
                            'isPreview' => true
                        ])
                    </div>
                </div>
        </div>
    </div>
</main>
@endsection

@section('styles')
<style>
    .app-main {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    
    .settings-card {
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .settings-card.disabled {
        opacity: 0.4;
        background-color: #f8f9fa;
    }
    
    .settings-card .card-header {
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 0.75rem 1rem;
    }
    
    .settings-card .card-body {
        padding: 1rem;
    }
    
    .link-item {
        padding: 0.5rem;
        background: #f8f9fa;
        border-radius: 0.375rem;
        border-left: 3px solid #0d6efd;
        transition: all 0.2s ease;
    }
    
    .link-item:hover {
        background: #e9ecef;
        transform: translateX(2px);
    }
    
    .social-inputs .input-group-text {
        min-width: 45px;
        justify-content: center;
    }
    
    .preview-container {
        position: relative;
        margin-top: auto;
        background: #fff;
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
        border-top: 1px solid #dee2e6;
    }
    
    #previewContent {
        transition: max-height 0.3s ease;
    }
    
    .form-text.smaller {
        font-size: 0.75rem;
    }
    
    .card-header.bg-gradient-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    /* Scrollbar styling */
    .card-body::-webkit-scrollbar {
        width: 6px;
    }
    
    .card-body::-webkit-scrollbar-track {
        background: #f1f1f1;
    }
    
    .card-body::-webkit-scrollbar-thumb {
        background: #c1c1c1;
        border-radius: 3px;
    }
    
    .card-body::-webkit-scrollbar-thumb:hover {
        background: #a8a8a8;
    }
</style>
@endsection

@section('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Section toggling
        document.querySelectorAll('.section-toggle').forEach(toggle => {
            toggle.addEventListener('change', function() {
                const settingsCard = this.closest('.settings-card');
                const sectionContent = settingsCard.querySelector('.section-content');
                
                if (this.checked) {
                    settingsCard.classList.remove('disabled');
                    if (sectionContent) sectionContent.style.display = 'block';
                } else {
                    settingsCard.classList.add('disabled');
                    if (sectionContent) sectionContent.style.display = 'none';
                }
            });
            
            // Trigger initial state
            toggle.dispatchEvent(new Event('change'));
        });

        // Toggle all sections
        document.getElementById('toggleAllSections').addEventListener('click', function() {
            const toggles = document.querySelectorAll('.section-toggle');
            const allChecked = Array.from(toggles).every(t => t.checked);
            
            toggles.forEach(toggle => {
                toggle.checked = !allChecked;
                toggle.dispatchEvent(new Event('change'));
            });
            
            this.innerHTML = allChecked ? 
                '<i class="bi bi-layers me-1"></i> Enable All' : 
                '<i class="bi bi-layers me-1"></i> Disable All';
        });

        // Quick Links Management
        let linkIndex = {{ count($footer['quick_links'] ?? []) }};
        const quickLinksContainer = document.getElementById('quickLinksContainer');
        
        document.getElementById('addQuickLink').addEventListener('click', function() {
            const template = `
                <div class="link-item mb-2" data-index="${linkIndex}">
                    <div class="d-flex gap-2 align-items-start">
                        <div class="flex-grow-1">
                            <div class="row g-1">
                                <div class="col-6">
                                    <input type="text" 
                                           name="footer[quick_links][${linkIndex}][label]"
                                           class="form-control form-control-sm"
                                           placeholder="Label"
                                           required>
                                </div>
                                <div class="col-6">
                                    <input type="text" 
                                           name="footer[quick_links][${linkIndex}][url]"
                                           class="form-control form-control-sm"
                                           placeholder="URL">
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-link">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>`;
            
            quickLinksContainer.insertAdjacentHTML('beforeend', template);
            linkIndex++;
        });

        // Remove link
        quickLinksContainer.addEventListener('click', function(e) {
            if (e.target.closest('.remove-link')) {
                e.target.closest('.link-item').remove();
                reindexLinks();
            }
        });

        function reindexLinks() {
            const links = quickLinksContainer.querySelectorAll('.link-item');
            links.forEach((link, index) => {
                link.dataset.index = index;
                const inputs = link.querySelectorAll('input');
                inputs[0].name = `footer[quick_links][${index}][label]`;
                inputs[1].name = `footer[quick_links][${index}][url]`;
            });
            linkIndex = links.length;
        }

        // Preview toggle
        const previewToggle = document.getElementById('livePreviewToggle');
        const previewContainer = document.getElementById('previewContainer');
        
        previewToggle.addEventListener('change', function() {
            previewContainer.style.display = this.checked ? 'block' : 'none';
        });

        // Collapse/expand preview
        const togglePreviewBtn = document.getElementById('togglePreview');
        const previewContent = document.getElementById('previewContent');
        const previewIcon = document.getElementById('previewIcon');
        let previewExpanded = true;
        
        togglePreviewBtn.addEventListener('click', function() {
            previewExpanded = !previewExpanded;
            
            if (previewExpanded) {
                previewContent.style.maxHeight = '50vh';
                previewIcon.className = 'bi bi-chevron-up';
                togglePreviewBtn.title = 'Collapse Preview';
            } else {
                previewContent.style.maxHeight = '0';
                previewIcon.className = 'bi bi-chevron-down';
                togglePreviewBtn.title = 'Expand Preview';
            }
        });

        // Real-time preview updates
        let previewTimeout;
        const updatePreview = () => {
            // Collect form data
            const formData = new FormData(document.getElementById('footerForm'));
            const formObject = {};
            
            for (let [key, value] of formData.entries()) {
                // Build nested object structure
                const keys = key.split(/\[|\]/).filter(k => k !== '');
                let current = formObject;
                
                for (let i = 0; i < keys.length - 1; i++) {
                    if (!current[keys[i]]) {
                        current[keys[i]] = isNaN(keys[i + 1]) ? {} : [];
                    }
                    current = current[keys[i]];
                }
                
                const lastKey = keys[keys.length - 1];
                if (current instanceof Array) {
                    current.push(value);
                } else {
                    current[lastKey] = value;
                }
            }
            
            // Here you could implement AJAX to update the preview
            // For now, we'll just show a notification
            const previewNotice = document.createElement('div');
            previewNotice.className = 'alert alert-info alert-dismissible fade show position-fixed bottom-0 end-0 m-3';
            previewNotice.style.zIndex = '1060';
            previewNotice.innerHTML = `
                <i class="bi bi-info-circle me-2"></i>Preview updated with new settings
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.body.appendChild(previewNotice);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                if (previewNotice.parentNode) {
                    previewNotice.remove();
                }
            }, 3000);
        };

        // Debounced form input listener for live preview
        document.querySelectorAll('#footerForm input, #footerForm textarea, #footerForm select').forEach(input => {
            input.addEventListener('input', function() {
                clearTimeout(previewTimeout);
                previewTimeout = setTimeout(updatePreview, 1000);
            });
            
            input.addEventListener('change', function() {
                clearTimeout(previewTimeout);
                updatePreview();
            });
        });

        // Form validation
        document.getElementById('footerForm').addEventListener('submit', function(e) {
            const activeSections = document.querySelectorAll('.section-toggle:checked');
            if (activeSections.length === 0) {
                if (!confirm('All sections are disabled. Are you sure you want to continue?')) {
                    e.preventDefault();
                }
            }
        });

        // Reset form
        document.querySelector('button[type="reset"]').addEventListener('click', function() {
            if (confirm('Are you sure you want to reset all changes?')) {
                // Reset section toggles
                document.querySelectorAll('.section-toggle').forEach(toggle => {
                    toggle.checked = true;
                    toggle.dispatchEvent(new Event('change'));
                });
                
                // Reset toggle all button
                document.getElementById('toggleAllSections').innerHTML = 
                    '<i class="bi bi-layers me-1"></i> Disable All';
            }
        });
    });
</script>
@endsection