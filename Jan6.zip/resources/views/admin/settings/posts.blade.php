{{-- resources/views/admin/settings/posts-page.blade.php --}}
@extends('admin.app')

@section('content')
<main class="app-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-gradient-primary py-3">
                        <h4 class="mb-0">
                            <i class="fas fa-newspaper me-2"></i>Posts Page Settings
                        </h4>
                        <small class="opacity-75">Customize your blog posts listing page</small>
                    </div>
                    
                    <form action="{{ route('settings.posts.update') }}" method="POST" id="postsPageForm" enctype="multipart/form-data">
                        @csrf
                        
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Validation Errors</h5>
                                    <ul class="mb-0 ps-3">
                                        @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            
                            {{-- Page Status --}}
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-semibold">Posts Page Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="1" {{ $status ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ !$status ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                        <div class="form-text">When inactive, the posts page will show a maintenance message.</div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Hero Section --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-heading me-2"></i>Hero Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Background Image</label>
                                            <div class="image-upload-wrapper">
                                                <div class="image-preview mb-2" id="heroBgPreview">
                                                    @if(!empty($postsPageData['hero']['hero_bg']))
                                                        <img src="{{ asset('assets/posts-page/' . $postsPageData['hero']['hero_bg']) }}" 
                                                             class="img-fluid rounded" 
                                                             style="max-height: 150px;">
                                                        <div class="mt-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" 
                                                                       type="checkbox" 
                                                                       name="remove_images[hero_bg]" 
                                                                       value="1"
                                                                       id="removeHeroBg">
                                                                <label class="form-check-label text-danger" for="removeHeroBg">
                                                                    Remove this image
                                                                </label>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="no-image-placeholder">
                                                            <i class="fas fa-mountain fa-3x text-muted"></i>
                                                            <p class="mt-2 text-muted">No background image selected</p>
                                                        </div>
                                                    @endif
                                                </div>
                                                <input type="file" 
                                                       name="hero_bg_image" 
                                                       class="form-control" 
                                                       id="heroBgInput"
                                                       accept="image/*">
                                                <input type="hidden" 
                                                       name="current_images[hero_bg]" 
                                                       value="{{ $postsPageData['hero']['hero_bg'] ?? '' }}">
                                                <div class="form-text">Recommended: 1920x600px wide image for hero background.</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Hero Title</label>
                                            <input type="text" 
                                                   name="hero[title]" 
                                                   class="form-control"
                                                   value="{{ old('hero.title', $postsPageData['hero']['title'] ?? 'My Stories & Thoughts') }}"
                                                   placeholder="e.g., My Stories & Thoughts">
                                        </div>
                                        
                                        <div class="col-12">
                                            <label class="form-label">Hero Description</label>
                                            <textarea name="hero[description]" 
                                                      class="form-control" 
                                                      rows="2"
                                                      placeholder="Explore my journey through personal stories, reflections, and experiences...">{{ old('hero.description', $postsPageData['hero']['description'] ?? '') }}</textarea>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Search Placeholder Text</label>
                                            <input type="text" 
                                                   name="hero[search_placeholder]" 
                                                   class="form-control"
                                                   value="{{ old('hero.search_placeholder', $postsPageData['hero']['search_placeholder'] ?? 'Search posts...') }}"
                                                   placeholder="e.g., Search posts...">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Filter Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter & Search Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="filter[show_search]"
                                                       value="1"
                                                       {{ old('filter.show_search', $postsPageData['filter']['show_search'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Search Bar</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="filter[show_category_filter]"
                                                       value="1"
                                                       {{ old('filter.show_category_filter', $postsPageData['filter']['show_category_filter'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Category Filter</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="filter[show_sort_options]"
                                                       value="1"
                                                       {{ old('filter.show_sort_options', $postsPageData['filter']['show_sort_options'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Sort Options</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Default Sort Option</label>
                                                <select name="filter[default_sort]" class="form-select">
                                                    <option value="newest" {{ old('filter.default_sort', $postsPageData['filter']['default_sort'] ?? 'newest') == 'newest' ? 'selected' : '' }}>Newest First</option>
                                                    <option value="oldest" {{ old('filter.default_sort', $postsPageData['filter']['default_sort'] ?? 'newest') == 'oldest' ? 'selected' : '' }}>Oldest First</option>
                                                    <option value="popular" {{ old('filter.default_sort', $postsPageData['filter']['default_sort'] ?? 'newest') == 'popular' ? 'selected' : '' }}>Most Popular</option>
                                                    <option value="commented" {{ old('filter.default_sort', $postsPageData['filter']['default_sort'] ?? 'newest') == 'commented' ? 'selected' : '' }}>Most Commented</option>
                                                </select>
                                            </div>
                                            
                                            @php
                                                $categories = \App\Models\Category::where('status', 1)->get();
                                            @endphp
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Default Category (Optional)</label>
                                                <select name="filter[default_category]" class="form-select">
                                                    <option value="">All Categories</option>
                                                    @foreach($categories as $category)
                                                        <option value="{{ $category->id }}" {{ old('filter.default_category', $postsPageData['filter']['default_category'] ?? '') == $category->id ? 'selected' : '' }}>
                                                            {{ $category->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                <div class="form-text">If set, posts will be filtered by this category by default</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Layout Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-th-large me-2"></i>Layout Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Posts Per Page</label>
                                                <input type="number" 
                                                       name="layout[posts_per_page]" 
                                                       class="form-control"
                                                       value="{{ old('layout.posts_per_page', $postsPageData['layout']['posts_per_page'] ?? 8) }}"
                                                       min="1"
                                                       max="50">
                                                <div class="form-text">Number of posts to show per page (1-50)</div>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="layout[show_sidebar]"
                                                       value="1"
                                                       {{ old('layout.show_sidebar', $postsPageData['layout']['show_sidebar'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Sidebar</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Grid Columns</label>
                                                <select name="layout[grid_columns]" class="form-select">
                                                    <option value="2" {{ old('layout.grid_columns', $postsPageData['layout']['grid_columns'] ?? 2) == 2 ? 'selected' : '' }}>2 Columns</option>
                                                    <option value="3" {{ old('layout.grid_columns', $postsPageData['layout']['grid_columns'] ?? 2) == 3 ? 'selected' : '' }}>3 Columns</option>
                                                    <option value="4" {{ old('layout.grid_columns', $postsPageData['layout']['grid_columns'] ?? 2) == 4 ? 'selected' : '' }}>4 Columns</option>
                                                </select>
                                                <div class="form-text">Number of columns in posts grid</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Sidebar Widgets --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-columns me-2"></i>Sidebar Widgets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_about_widget]"
                                                       value="1"
                                                       {{ old('sidebar.show_about_widget', $postsPageData['sidebar']['show_about_widget'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show About Widget</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_categories_widget]"
                                                       value="1"
                                                       {{ old('sidebar.show_categories_widget', $postsPageData['sidebar']['show_categories_widget'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Categories Widget</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_popular_posts_widget]"
                                                       value="1"
                                                       {{ old('sidebar.show_popular_posts_widget', $postsPageData['sidebar']['show_popular_posts_widget'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Popular Posts Widget</label>
                                            </div>
                                            
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="sidebar[show_newsletter_widget]"
                                                       value="1"
                                                       {{ old('sidebar.show_newsletter_widget', $postsPageData['sidebar']['show_newsletter_widget'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Newsletter Widget</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">About Widget Title</label>
                                                <input type="text" 
                                                       name="sidebar[about_widget_title]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.about_widget_title', $postsPageData['sidebar']['about_widget_title'] ?? 'About This Blog') }}">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">About Widget Content</label>
                                                <textarea name="sidebar[about_widget_content]" 
                                                          class="form-control" 
                                                          rows="3">{{ old('sidebar.about_widget_content', $postsPageData['sidebar']['about_widget_content'] ?? '') }}</textarea>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Popular Posts Title</label>
                                                <input type="text" 
                                                       name="sidebar[popular_posts_title]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.popular_posts_title', $postsPageData['sidebar']['popular_posts_title'] ?? 'Popular Posts') }}">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Popular Posts Count</label>
                                                <input type="number" 
                                                       name="sidebar[popular_posts_count]" 
                                                       class="form-control"
                                                       value="{{ old('sidebar.popular_posts_count', $postsPageData['sidebar']['popular_posts_count'] ?? 5) }}"
                                                       min="1"
                                                       max="10">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Empty State --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-inbox me-2"></i>Empty State Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Empty State Title</label>
                                                <input type="text" 
                                                       name="empty_state[title]" 
                                                       class="form-control"
                                                       value="{{ old('empty_state.title', $postsPageData['empty_state']['title'] ?? 'No Posts Found') }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Empty State Message</label>
                                                <textarea name="empty_state[message]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('empty_state.message', $postsPageData['empty_state']['message'] ?? '') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Pagination --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-ellipsis-h me-2"></i>Pagination Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-check form-switch mb-3">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       name="pagination[show_pagination]"
                                                       value="1"
                                                       {{ old('pagination.show_pagination', $postsPageData['pagination']['show_pagination'] ?? true) ? 'checked' : '' }}>
                                                <label class="form-check-label">Show Pagination</label>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Pagination Type</label>
                                                <select name="pagination[type]" class="form-select">
                                                    <option value="simple" {{ old('pagination.type', $postsPageData['pagination']['type'] ?? 'both') == 'simple' ? 'selected' : '' }}>Simple (Previous/Next)</option>
                                                    <option value="numbered" {{ old('pagination.type', $postsPageData['pagination']['type'] ?? 'both') == 'numbered' ? 'selected' : '' }}>Numbered Pages</option>
                                                    <option value="both" {{ old('pagination.type', $postsPageData['pagination']['type'] ?? 'both') == 'both' ? 'selected' : '' }}>Both</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- SEO Meta Settings --}}
                            <div class="section-card card border mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-search me-2"></i>SEO Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Title</label>
                                                <input type="text" 
                                                       name="meta[meta_title]" 
                                                       class="form-control"
                                                       value="{{ old('meta.meta_title', $postsPageData['meta']['meta_title'] ?? 'My Stories & Thoughts | Blog') }}">
                                                <div class="form-text">Page title for SEO (50-60 characters recommended)</div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Meta Keywords</label>
                                                <textarea name="meta[meta_keywords]" 
                                                          class="form-control" 
                                                          rows="2">{{ old('meta.meta_keywords', $postsPageData['meta']['meta_keywords'] ?? '') }}</textarea>
                                                <div class="form-text">Comma-separated keywords</div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Meta Description</label>
                                                <textarea name="meta[meta_description]" 
                                                          class="form-control" 
                                                          rows="4">{{ old('meta.meta_description', $postsPageData['meta']['meta_description'] ?? '') }}</textarea>
                                                <div class="form-text">Page description for SEO (150-160 characters recommended)</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer bg-light border-top py-3">
                            <div class="d-flex justify-content-between">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Reset Changes
                                </button>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-save me-1"></i> Save Posts Page Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image preview for hero background
    const heroBgInput = document.getElementById('heroBgInput');
    const heroBgPreview = document.getElementById('heroBgPreview');
    
    if (heroBgInput && heroBgPreview) {
        heroBgInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'img-fluid rounded';
                    img.style = 'max-height: 150px;';
                    
                    heroBgPreview.innerHTML = '';
                    
                    // Create image container
                    const imgContainer = document.createElement('div');
                    imgContainer.appendChild(img);
                    
                    // Add remove checkbox
                    const removeDiv = document.createElement('div');
                    removeDiv.className = 'mt-2';
                    removeDiv.innerHTML = `
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="remove_images[hero_bg]" 
                                   value="1"
                                   id="removeHeroBg">
                            <label class="form-check-label text-danger" for="removeHeroBg">
                                Remove this image
                            </label>
                        </div>
                    `;
                    
                    heroBgPreview.appendChild(imgContainer);
                    heroBgPreview.appendChild(removeDiv);
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
});
</script>
@endsection