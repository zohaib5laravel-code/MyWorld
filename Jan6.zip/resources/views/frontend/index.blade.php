@extends('frontend.app')
@section('content')

@php
    // Get homepage settings
    $homepageSetting = \App\Models\Setting::where('key', 'homepage')->first();
    $settings = $homepageSetting ? json_decode($homepageSetting->value, true) : [];
    $status = $homepageSetting ? (bool)$homepageSetting->status : true;
    
    // Helper function to get setting with default
    function getHomepageSetting($key, $default = null, $settings) {
        $keys = explode('.', $key);
        $value = $settings;
        
        foreach ($keys as $k) {
            if (is_array($value) && array_key_exists($k, $value)) {
                $value = $value[$k];
            } else {
                return $default;
            }
        }
        
        return $value ?? $default;
    }
    
    // Set defaults
    $defaults = [
        'hero' => [
            'title' => 'Welcome to <span class="text-warning">My World</span>',
            'subtitle' => 'This is my personal space where I share my journey through photos, stories, and experiences. Every image tells a story, and every post captures a moment in time.',
            'button1_text' => 'Explore Gallery',
            'button1_url' => '#gallery',
            'button2_text' => 'Read Posts',
            'button2_url' => '#posts',
            'show_world_icon' => 1,
            'hero_bg' => '',
        ],
        'carousel' => [
            'enabled' => 1,
            'interval' => 5000,
            'show_indicators' => 1,
            'show_controls' => 1,
            'show_captions' => 1,
            'height' => 500,
        ],
        'posts' => [
            'enabled' => 1,
            'title' => 'Recent Posts',
            'subtitle' => '',
            'show_button' => 1,
            'button_text' => 'View All Posts',
            'posts_count' => 3,
            'show_featured_image' => 1,
            'show_date' => 1,
            'show_category' => 1,
            'show_excerpt' => 1,
            'excerpt_length' => 150,
        ],
        'gallery' => [
            'enabled' => 1,
            'title' => 'Photo Gallery',
            'subtitle' => 'A collection of my favorite moments captured through the lens',
            'show_button' => 1,
            'button_text' => 'View Full Gallery',
            'images_count' => 6,
            'show_overlay' => 1,
            'columns' => 3,
        ],
        'about' => [
            'enabled' => 1,
            'title' => 'About My World',
            'content' => 'Welcome to my personal corner of the internet. This space is a reflection of my journey, interests, and the moments that matter to me. Through photos and posts, I share glimpses of my experiences, thoughts, and discoveries. Each image in the gallery represents a memory, and every post is a story from my life.',
            'show_image' => 1,
            'image_url' => 'https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
            'show_social_icons' => 1,
            'social_links' => [
                ['platform' => 'instagram', 'url' => '#', 'icon' => 'fab fa-instagram'],
                ['platform' => 'twitter', 'url' => '#', 'icon' => 'fab fa-twitter'],
                ['platform' => 'facebook', 'url' => '#', 'icon' => 'fab fa-facebook'],
                ['platform' => 'pinterest', 'url' => '#', 'icon' => 'fab fa-pinterest'],
            ],
        ],
    ];
    
    // Merge settings with defaults
    $settings = array_replace_recursive($defaults, $settings);
    
    // Get individual settings
    $carouselEnabled = getHomepageSetting('carousel.enabled', 1, $settings);
    $carouselInterval = getHomepageSetting('carousel.interval', 5000, $settings);
    $showCarouselIndicators = getHomepageSetting('carousel.show_indicators', 1, $settings);
    $showCarouselControls = getHomepageSetting('carousel.show_controls', 1, $settings);
    $showCarouselCaptions = getHomepageSetting('carousel.show_captions', 1, $settings);
    $carouselHeight = getHomepageSetting('carousel.height', 500, $settings);
    
    $heroTitle = getHomepageSetting('hero.title', 'Welcome to <span class="text-warning">My World</span>', $settings);
    $heroSubtitle = getHomepageSetting('hero.subtitle', '', $settings);
    $heroButton1Text = getHomepageSetting('hero.button1_text', 'Explore Gallery', $settings);
    $heroButton1Url = getHomepageSetting('hero.button1_url', '#gallery', $settings);
    $heroButton2Text = getHomepageSetting('hero.button2_text', 'Read Posts', $settings);
    $heroButton2Url = getHomepageSetting('hero.button2_url', '#posts', $settings);
    $showWorldIcon = getHomepageSetting('hero.show_world_icon', 1, $settings);
    
    $postsEnabled = getHomepageSetting('posts.enabled', 1, $settings);
    $postsTitle = getHomepageSetting('posts.title', 'Recent Posts', $settings);
    $postsSubtitle = getHomepageSetting('posts.subtitle', '', $settings);
    $postsShowButton = getHomepageSetting('posts.show_button', 1, $settings);
    $postsButtonText = getHomepageSetting('posts.button_text', 'View All Posts', $settings);
    $postsCount = getHomepageSetting('posts.posts_count', 3, $settings);
    $showFeaturedImage = getHomepageSetting('posts.show_featured_image', 1, $settings);
    $showPostDate = getHomepageSetting('posts.show_date', 1, $settings);
    $showPostCategory = getHomepageSetting('posts.show_category', 1, $settings);
    $showExcerpt = getHomepageSetting('posts.show_excerpt', 1, $settings);
    $excerptLength = getHomepageSetting('posts.excerpt_length', 150, $settings);
    
    $galleryEnabled = getHomepageSetting('gallery.enabled', 1, $settings);
    $galleryTitle = getHomepageSetting('gallery.title', 'Photo Gallery', $settings);
    $gallerySubtitle = getHomepageSetting('gallery.subtitle', 'A collection of my favorite moments captured through the lens', $settings);
    $galleryShowButton = getHomepageSetting('gallery.show_button', 1, $settings);
    $galleryButtonText = getHomepageSetting('gallery.button_text', 'View Full Gallery', $settings);
    $galleryImagesCount = getHomepageSetting('gallery.images_count', 6, $settings);
    $showGalleryOverlay = getHomepageSetting('gallery.show_overlay', 1, $settings);
    $galleryColumns = getHomepageSetting('gallery.columns', 3, $settings);
    
    $aboutEnabled = getHomepageSetting('about.enabled', 1, $settings);
    $aboutTitle = getHomepageSetting('about.title', 'About My World', $settings);
    $aboutContent = getHomepageSetting('about.content', '', $settings);
    $showAboutImage = getHomepageSetting('about.show_image', 1, $settings);
    $aboutImageUrl = getHomepageSetting('about.image_url', '', $settings);
    $showSocialIcons = getHomepageSetting('about.show_social_icons', 1, $settings);
    $socialLinks = getHomepageSetting('about.social_links', [], $settings);
    
    // Set hero background
    $heroBg = !empty($settings['hero']['hero_bg']) 
        ? asset('assets/homepage/' . $settings['hero']['hero_bg'])
        : '';
@endphp

<style>
    .hero-section {
        background: linear-gradient(rgba(21, 26, 34, 0.9),
            rgba(22, 96, 136, 0.9)){{ $heroBg ? ", url('{$heroBg}')" : '' }};
        background-size: cover;
        background-position: center;
        color: white;
        padding: 80px 0;
        margin-bottom: 40px;
    }
    
    .carousel-item img {
        height: {{ $carouselHeight }}px;
        object-fit: cover;
    }
    
    /* Gallery grid columns */
    @php
        $gridClass = match($galleryColumns) {
            2 => 'col-md-6',
            3 => 'col-md-4',
            4 => 'col-md-3',
            6 => 'col-md-2',
            default => 'col-md-4'
        };
    @endphp
    
    .gallery-item {
        margin-bottom: 30px;
    }
    
    .gallery-item img {
        width: 100%;
        height: 250px;
        object-fit: cover;
        border-radius: 8px;
    }
    
    .gallery-overlay {
        transition: opacity 0.3s ease;
    }
    
    .gallery-item:hover .gallery-overlay {
        opacity: 1;
    }
</style>

<!-- Check if page is active -->
@if(!$status)
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 mx-auto text-center">
                <div class="card shadow-sm">
                    <div class="card-body py-5">
                        <i class="fas fa-tools fa-3x text-muted mb-4"></i>
                        <h3 class="mb-3">Homepage Under Maintenance</h3>
                        <p class="text-muted">We're currently updating our homepage. Please check back soon!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@else
    @if($carouselEnabled)
    <section class="banner-carousel">
        <!-- Carousel -->
        <div id="bannerCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-wrap="true" data-bs-interval="{{ $carouselInterval }}">
            @if($showCarouselIndicators)
            <!-- Indicators -->
            <div class="carousel-indicators">
                @if(isset($pictures) && $pictures->where('type','banner')->count() > 0)
                @php $banners = $pictures->where('type','banner') @endphp
                @foreach($banners as $banner)
                <button
                    type="button"
                    data-bs-target="#bannerCarousel"
                    data-bs-slide-to="{{ $loop->index }}"
                    class="{{ $loop->first ? 'active' : '' }}"
                    aria-label="Slide {{ $loop->iteration }}">
                </button>
                @endforeach
                @else
                <button type="button"
                    data-bs-target="#bannerCarousel"
                    data-bs-slide-to="0"
                    class="active"
                    aria-label="Slide 1">
                </button>
                <button type="button"
                    data-bs-target="#bannerCarousel"
                    data-bs-slide-to="1"
                    aria-label="Slide 2">
                </button>
                <button type="button"
                    data-bs-target="#bannerCarousel"
                    data-bs-slide-to="2"
                    aria-label="Slide 3">
                </button>
                @endif
            </div>
            @endif

            <!-- Carousel Items -->
            <div class="carousel-inner">
                @if(isset($pictures) && $pictures->where('type','banner')->count() > 0)
                @php $banners = $pictures->where('type','banner') @endphp
                @foreach($banners as $banner)
                <div class="carousel-item {{ $loop->first ? 'active' : '' }}">
                    <img loading="lazy" src="{{ asset('assets/pictures/' . $banner->image) }}"
                        class="d-block w-100"
                        alt="{{ $banner->title ?? 'Banner Image' }}">
                    @if($showCarouselCaptions && $banner->title)
                    <div class="carousel-caption d-none d-md-block">
                        <p>{!! $banner->title !!}</p>
                    </div>
                    @endif
                </div>
                @endforeach
                @else
                <!-- Default banners if none in database -->
                <div class="carousel-item active">
                    <img loading="lazy" src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
                        class="d-block w-100"
                        alt="My World Banner 1">
                    @if($showCarouselCaptions)
                    <div class="carousel-caption d-none d-md-block">
                        <h3>Welcome to My World</h3>
                        <p>A personal space to share my journey, thoughts, and memories</p>
                    </div>
                    @endif
                </div>
                <div class="carousel-item">
                    <img loading="lazy" src="https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
                        class="d-block w-100"
                        alt="My World Banner 2">
                    @if($showCarouselCaptions)
                    <div class="carousel-caption d-none d-md-block">
                        <h3>Explore My Gallery</h3>
                        <p>Discover the moments I've captured and want to share with you</p>
                    </div>
                    @endif
                </div>
                <div class="carousel-item">
                    <img loading="lazy" src="https://images.unsplash.com/photo-1518837695005-2083093ee35b?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
                        class="d-block w-100"
                        alt="My World Banner 3">
                    @if($showCarouselCaptions)
                    <div class="carousel-caption d-none d-md-block">
                        <h3>Read My Stories</h3>
                        <p>Personal posts about experiences, thoughts, and discoveries</p>
                    </div>
                    @endif
                </div>
                @endif
            </div>

            @if($showCarouselControls)
            <!-- Controls -->
            <button class="carousel-control-prev" type="button" data-bs-target="#bannerCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#bannerCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            @endif
        </div>
    </section>
    @endif

    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-4 mb-4">{!! $heroTitle !!}</h1>
                    <p class="lead mb-4">{{ $heroSubtitle }}</p>
                    <a href="{{ $heroButton1Url }}" class="btn btn-primary btn-lg me-3">
                        <i class="fas fa-images me-2"></i>{{ $heroButton1Text }}
                    </a>
                    <a href="{{ $heroButton2Url }}" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-newspaper me-2"></i>{{ $heroButton2Text }}
                    </a>
                </div>
                @if($showWorldIcon)
                <div class="col-lg-4 text-center">
                    <div class="rounded-circle bg-white p-4 d-inline-block">
                        <i class="fas fa-globe-americas text-primary" style="font-size: 6rem;"></i>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </section>

    @if($postsEnabled)
    <section id="posts" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title">{{ $postsTitle }}</h2>
            @if($postsSubtitle)
            <p class="section-subtitle">{{ $postsSubtitle }}</p>
            @endif

            <div class="row">
                <!-- Dynamic content from Laravel backend -->
                @if(isset($posts) && count($posts) > 0)
                @foreach($posts->take($postsCount) as $post)
                <div class="col-md-4 mb-4">
                    <div class="card featured-post shadow-sm h-100">
                        @if($showFeaturedImage)
                        @if($post->featured_image)
                        <img loading="lazy" src="{{ asset('assets/posts/' . $post->featured_image) }}" class="card-img-top" alt="{{ $post->title }}" style="height: 200px; object-fit: cover;">
                        @else
                        <img loading="lazy" src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="Post Image" style="height: 200px; object-fit: cover;">
                        @endif
                        @endif
                        <div class="card-body">
                            @if($showPostDate || $showPostCategory)
                            <div class="post-meta mb-2">
                                @if($showPostDate)
                                <i class="far fa-calendar"></i> {{ $post->created_at->format('M d, Y') }}
                                @endif
                                @if($showPostCategory)
                                <i class="fas fa-tag ms-3"></i> {{ $post->category->name }}
                                @endif
                            </div>
                            @endif
                            <h5 class="card-title">{{ $post->title }}</h5>
                            @if($showExcerpt)
                            <p class="card-text">{!! Str::limit($post->content, $excerptLength) !!}</p>
                            @endif
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="{{ route('frontend.post', $post->slug) }}" class="btn btn-outline-primary">Read More</a>
                        </div>
                    </div>
                </div>
                @endforeach
                @else
                <!-- Default posts if none in database -->
                <div class="col-md-4 mb-4">
                    <div class="card featured-post shadow-sm h-100">
                        @if($showFeaturedImage)
                        <img loading="lazy" src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="Post Image">
                        @endif
                        <div class="card-body">
                            @if($showPostDate || $showPostCategory)
                            <div class="post-meta mb-2">
                                @if($showPostDate)
                                <i class="far fa-calendar"></i> June 15, 2023
                                @endif
                                @if($showPostCategory)
                                <i class="fas fa-tag ms-3"></i> Travel
                                @endif
                            </div>
                            @endif
                            <h5 class="card-title">My Journey to the Mountains</h5>
                            @if($showExcerpt)
                            <p class="card-text">Discovering the beauty of nature and finding peace in the high altitudes. An unforgettable experience that changed my perspective.</p>
                            @endif
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="{{ route('frontend.posts') }}" class="btn btn-outline-primary">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card featured-post shadow-sm h-100">
                        @if($showFeaturedImage)
                        <img loading="lazy" src="https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="Post Image">
                        @endif
                        <div class="card-body">
                            @if($showPostDate || $showPostCategory)
                            <div class="post-meta mb-2">
                                @if($showPostDate)
                                <i class="far fa-calendar"></i> May 22, 2023
                                @endif
                                @if($showPostCategory)
                                <i class="fas fa-tag ms-3"></i> Food
                                @endif
                            </div>
                            @endif
                            <h5 class="card-title">Culinary Adventures in Italy</h5>
                            @if($showExcerpt)
                            <p class="card-text">Exploring the rich flavors of Italian cuisine, from homemade pasta to the perfect espresso. A food lover's dream come true.</p>
                            @endif
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="{{ route('frontend.posts') }}" class="btn btn-outline-primary">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card featured-post shadow-sm h-100">
                        @if($showFeaturedImage)
                        <img loading="lazy" src="https://images.unsplash.com/photo-1545235617-9465d2a55698?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="Post Image">
                        @endif
                        <div class="card-body">
                            @if($showPostDate || $showPostCategory)
                            <div class="post-meta mb-2">
                                @if($showPostDate)
                                <i class="far fa-calendar"></i> April 10, 2023
                                @endif
                                @if($showPostCategory)
                                <i class="fas fa-tag ms-3"></i> Reflection
                                @endif
                            </div>
                            @endif
                            <h5 class="card-title">Finding Balance in a Busy World</h5>
                            @if($showExcerpt)
                            <p class="card-text">Thoughts on maintaining mental well-being and finding moments of peace in our increasingly fast-paced lives.</p>
                            @endif
                        </div>
                        <div class="card-footer bg-transparent">
                            <a href="{{ route('frontend.posts') }}" class="btn btn-outline-primary">Read More</a>
                        </div>
                    </div>
                </div>
                @endif
            </div>

            @if($postsShowButton)
            <div class="text-center mt-4">
                <a href="{{ route('frontend.posts') }}" class="btn btn-primary btn-lg">{{ $postsButtonText }}</a>
            </div>
            @endif
        </div>
    </section>
    @endif

    @if($galleryEnabled)
    <section id="gallery" class="py-5">
        <div class="container">
            <h2 class="section-title text-center">{{ $galleryTitle }}</h2>
            @if($gallerySubtitle)
            <p class="text-center mb-5">{{ $gallerySubtitle }}</p>
            @endif

            <div class="row">
                <!-- Dynamic content from Laravel backend -->
                @if(isset($pictures) && $pictures->where('type','gallery')->count() > 0)
                @foreach($pictures->where('type','gallery')->take($galleryImagesCount) as $image)
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="{{ asset('assets/pictures/' . $image->image) }}" alt="{{ $image->title }}">
                        @if($showGalleryOverlay && $image->title)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">{!! $image->title !!}</p>
                        </div>
                        @endif
                    </div>
                </div>
                @endforeach
                @else
                <!-- Default gallery images if none in database -->
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Mountain Landscape">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">Mountain Landscape</p>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1439066615861-d1af74d74000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Forest Path">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">Forest Path</p>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Ocean Waves">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">Ocean Waves</p>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1518837695005-2083093ee35b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="City Lights">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">City Lights</p>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Snowy Peaks">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">Snowy Peaks</p>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="{{ $gridClass }}">
                    <div class="gallery-item shadow">
                        <img loading="lazy" src="https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Northern Lights">
                        @if($showGalleryOverlay)
                        <div class="gallery-overlay position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-50 text-white opacity-0 hover-opacity-100 transition-all">
                            <p class="text-center">Northern Lights</p>
                        </div>
                        @endif
                    </div>
                </div>
                @endif
            </div>

            @if($galleryShowButton)
            <div class="text-center mt-4">
                <a href="{{ route('frontend.gallery') }}" class="btn btn-primary btn-lg">{{ $galleryButtonText }}</a>
            </div>
            @endif
        </div>
    </section>
    @endif

    @if($aboutEnabled)
    <section id="about" class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="section-title">{{ $aboutTitle }}</h2>
                    <p>{{ $aboutContent }}</p>
                    
                    @if($showSocialIcons && !empty($socialLinks))
                    <div class="mt-4">
                        <h5>Follow My Journey</h5>
                        <div class="social-icons">
                            @foreach($socialLinks as $social)
                            <a href="{{ $social['url'] }}" target="_blank" rel="noopener noreferrer">
                                <i class="{{ $social['icon'] }}"></i>
                            </a>
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
                @if($showAboutImage)
                <div class="col-lg-6">
                    <div class="rounded shadow overflow-hidden">
                        <img loading="lazy" src="{{ $aboutImageUrl ?: 'https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80' }}" 
                             alt="About My World" 
                             class="img-fluid">
                    </div>
                </div>
                @endif
            </div>
        </div>
    </section>
    @endif
@endif

@endsection

@section('scripts')
<script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            if (this.getAttribute('href') !== '#') {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    @if($carouselEnabled)
    const myCarousel = document.querySelector('#bannerCarousel');
    const carousel = new bootstrap.Carousel(myCarousel, {
        interval: {{ $carouselInterval }},
        wrap: true,
        keyboard: true
    });
    @endif
</script>

@endsection